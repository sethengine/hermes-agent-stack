---
name: linux-performance-tuning
version: "1.0.0"
description: "Systematic Linux performance auditing and tuning for gaming/workstation hybrid systems — hardware audit, kernel config, IRQ pinning, hybrid CPU scheduling, NVIDIA Wayland optimization, network latency, and context switch investigation."
author: hermes-agent
allowed-tools: Bash, Read, Write, WebSearch
---

# Linux Performance Tuning

Systematic methodology for auditing and tuning Linux systems, especially hybrid CPU architectures (P-cores + E-cores) used for gaming + workstation workloads.

## Triggers

Use this skill when the user asks about any of:
- System performance audit / "find tweaks for my system"
- IRQ pinning or interrupt affinity tuning
- High context switches or input lag
- Scheduler tuning for gaming on hybrid CPUs
- NVIDIA + Wayland performance optimization
- "What configs are making my system slow"
- "Investigate my system for performance issues"

## Multi-Layer System Audit

Do NOT skip layers. Each layer can reveal issues the others hide.

### Layer 1 — Hardware baseline
```
cat /proc/cpuinfo | grep -m1 "model name"        # CPU
cat /proc/cpuinfo | grep -c "^processor"         # Core count
lspci | grep -i "vga\|3d"                        # GPU
free -h                                          # RAM
lsblk -d -o NAME,SIZE,ROTA,MODEL                 # Disks
uname -a                                         # Kernel version
lsmod | grep nvidia                              # NVIDIA modules
```

### Layer 2 — Boot params and kernel config
```
cat /proc/cmdline                                 # Active kernel params
grep GRUB_CMDLINE_LINUX_DEFAULT /etc/default/grub # Persistent config
cat /sys/devices/system/cpu/intel_pstate/*        # P-state settings
cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
```

### Layer 3 — Config files audit (check ALL of these)
- `/etc/modprobe.d/*.conf` — module parameters and blacklists
- `/etc/environment` — system-wide env vars
- `~/.config/environment.d/*.conf` — per-service env vars
- `~/.profile` — shell env vars
- `~/.asoundrc` — ALSA config
- `/etc/systemd/system/*.service` — custom systemd units
- `/etc/sysctl.d/*.conf` — kernel tunables
- `/etc/fstab` — mount options
- `/etc/default/grub` — boot params
- `~/.config/kwinrc` — KDE compositor settings

### Layer 4 — Systemd services audit
```
systemctl --failed
systemctl list-timers
systemctl list-units --type=service --state=running
```

### Layer 5 — Environment variable conflicts
Check for DIFFERENT values of the same var across `/etc/environment`, `~/.profile`, `~/.config/environment.d/*.conf`. Common conflicts: `LIBVA_DRIVER_NAME`, `__GL_*`, `KWIN_*`, `DXVK_*`.

### Layer 6 — Memory and VM tuning
```
sysctl vm.swappiness vm.vfs_cache_pressure vm.dirty_ratio vm.dirty_background_ratio
cat /sys/kernel/mm/transparent_hugepage/enabled
cat /sys/kernel/mm/transparent_hugepage/defrag
cat /proc/sys/vm/watermark_boost_factor
cat /proc/sys/vm/watermark_scale_factor
```

### Layer 7 — Filesystem health
```
sudo tune2fs -l /dev/nvme1n1p1 | grep -E "Filesystem state|Errors"
df -h  # Check for >90% full partitions
```

### Layer 8 — Scheduler analysis
```
cat /proc/sys/kernel/sched_min_granularity_ns
cat /proc/sys/kernel/sched_latency_ns
cat /proc/sys/kernel/sched_wakeup_granularity_ns
```

## IRQ Pinning for Hybrid CPUs

### Architecture
On Intel hybrid CPUs (Arrow Lake, Raptor Lake, Alder Lake):
- P-cores: highest frequency, larger caches → **reserved for game/foreground**
- E-cores: lower frequency, smaller caches → **all hardware interrupts + background**

### Correct allocation for gaming

```
P-cores:    GAME + foreground apps (zero IRQs, zero interference)
E-core set A: GPU interrupts only
E-core set B: USB interrupts only (separate from GPU)
E-core set C: NVMe, audio, WiFi, ethernet, everything else
```

### Key principle
GPU IRQs and USB IRQs each need **dedicated, non-overlapping** E-cores. The GPU generates 100M+ interrupts per session — if USB shares the same core, mouse/keyboard input gets delayed by GPU IRQ processing.

### Script structure (see references/pin-irqs-dynamic.sh)
```bash
#!/bin/bash
# 1. GPU → E-cores 8-9 (dedicated)
# 2. USB xHCI → E-cores 10-11 (dedicated, no GPU overlap)
# 3. NVMe → E-cores 12-19
# 4. Audio → E-cores 12-19
# 5. WiFi → E-cores 12-19
# 6. Ethernet → E-cores 12-19
```

Each section uses round-robin within its assigned core range. `smp_affinity_list` takes a single CPU number (0-indexed).

### Pitfalls
- **IRQ numbers change between boots** — always grep by driver name, not IRQ number
- `smp_affinity_list` writes fail silently if the process lacks permission — run as root
- Check `cat /proc/interrupts | grep nvidia` after the script runs to verify cores
- `irqbalance` WILL override manual pinning — disable it if using a custom script
- Some NVIDIA IRQ vectors are idle (0 interrupts) — still pin them, the distribution logic handles it
- **NVMe IRQs are managed IRQs** — the NVMe driver may override manual affinity writes for queue completion IRQs (nvme0q1-nvme0q8, nvme1q1-nvme1q8). The write appears to succeed (no error) but the kernel reverts it. This is normal and acceptable since NVMe interrupts are low-rate compared to GPU (hundreds per second vs millions).
- **`isolcpus=domain,managed_irq,0-7` defeats NVMe isolation** — the `managed_irq` flag in `isolcpus` explicitly ALLOWS managed IRQs (MSI-X, such as NVMe queue completions) to target isolated CPUs. Without `managed_irq`, the kernel automatically excludes isolated CPUs from managed IRQ targets. If you see NVMe IO queues landing on isolated CPUs (check via `cat /proc/interrupts | grep nvme`), the fix is to **remove `managed_irq`** from your `isolcpus` parameter — e.g. `isolcpus=domain,0-7` instead of `isolcpus=domain,managed_irq,0-7`. This is a reboot-required change.
- **GPU + USB must NOT overlap** — GPU generates 100M+ interrupts and USB handles mouse/kb input. If they share the same E-core, input latency spikes when GPU IRQ processing delays USB IRQ handling. Dedicate separate E-core ranges.

### Diagnosing IRQ assignments

Before pinning, always verify current IRQ distribution to catch misconfigurations:

```bash
# 1. Check CPU topology
lscpu | grep -E '^CPU\\(s\\)|Core\\(s\\)|Thread'

# 2. Which CPUs are isolated?
cat /sys/devices/system/cpu/isolated

# 3. Overview — who is on which CPU
cat /proc/interrupts | grep -E 'nvidia|nvme|xhci_hcd|iwlwifi|snd_hda|igc'

# 4. Hex-to-CPU quick reference (for 20 CPUs):
#    00001=CPU0  00002=CPU1  00004=CPU2  00008=CPU3
#    00010=CPU4  00020=CPU5  00040=CPU6  00080=CPU7
#    00100=CPU8  00200=CPU9  00400=CPU10 00800=CPU11
#    01000=CPU12 02000=CPU13 04000=CPU14 08000=CPU15
#    10000=CPU16 20000=CPU17 40000=CPU18 80000=CPU19

# 5. Check configured vs actual runtime affinity
#    smp_affinity = what the kernel was told
#    effective_affinity = what's actually happening at runtime
for irq in $(grep "nvme" /proc/interrupts | awk '{print $1}' | tr -d ':'); do
  name=$(grep "^ *$irq:" /proc/interrupts | awk '{print $NF}')
  aff=$(cat /proc/irq/$irq/smp_affinity)
  eff=$(cat /proc/irq/$irq/effective_affinity)
  echo "IRQ $irq ($name): configured=$aff effective=$eff"
done

# 6. Classification helper
python3 -c "
data = open('/proc/interrupts').read()
for line in data.splitlines():
    if not any(x in line.lower() for x in ['nvidia','nvme','xhci','iwlwifi','snd_hda','igc']):
        continue
    parts = line.split()
    irq = parts[0].rstrip(':')
    if not irq.isdigit(): continue
    aff = open('/proc/irq/%s/smp_affinity' % irq).read().strip()
    eff = open('/proc/irq/%s/effective_affinity' % irq).read().strip()
    ev = int(eff.replace(',',''), 16)
    ec = [i for i in range(20) if ev & (1<<i)]
    iso = [c for c in ec if c < 8]
    hk = [c for c in ec if c >= 8]
    if iso and not hk: tag = 'ISOLATED ONLY'
    elif iso and hk:   tag = 'SPLIT'
    else:              tag = 'housekeeping'
    print('IRQ %3s aff=%6s eff=%6s CPUs=%-12s %s' % (irq, aff, eff, str(ec), tag))
"
```

See `references/irq-affinity-diagnosis.md` for the hex decoding table and standalone diagnosis script.

## References

- `references/gaming-scheduler-tunables.md` — Scheduler values and context switch investigation
- `references/sethengine-system-config-june-2026.md` — Full system reference for Arrow Lake 265K + RTX 5060 Ti
- `references/irq-affinity-diagnosis.md` — Hex mask decoding table and standalone IRQ diagnosis commands
- `references/pin-irqs-dynamic.sh` — Installable script for dynamic IRQ pinning

### C-state locking for IRQ cores
GPU/USB IRQ cores can enter deep C3 sleep (1048μs wake latency) between interrupts. Add this to the pin-irqs script to lock them to C1/C2:

```bash
cpupower -c 8-11 idle-set -D 2 >/dev/null 2>&1
cpupower -c 8-11 frequency-set -g performance >/dev/null 2>&1
```

This blocks C3+ sleep — cores stay in C1 (1μs) or C2 (127μs) wake latency, responding to interrupts at full speed. Add right before the "Done" line in the script.

### Reference script
See `references/pin-irqs-dynamic.sh` for the full installable script with all sections: NVIDIA→E-cores 8-9, USB→10-11, NVMe/audio/WiFi/ethernet→12-19.

### Session reference
`references/sethengine-system-config-june-2026.md` documents a real Arrow Lake 265K + RTX 5060 Ti + Z890 + Manjaro + KDE Wayland system with all configs, pitfalls, and fixes applied in a live session.

## Scheduler Tuning for Gaming on Hybrid CPUs

### The trap
`sched_min_granularity_ns=750000` (0.75ms) seems like "low latency" but **hurts gaming**:
- At 165fps (6ms/frame): game preempted ~8x per frame
- Each preemption = cache dump + TLB flush + resume overhead
- `sched_wakeup_granularity_ns=1000000` lets Chrome steal CPU from the game after just 1ms

### Recommended values for gaming/workstation hybrid
```ini
kernel.sched_min_granularity_ns=3000000     # 3ms — game runs longer without preemption
kernel.sched_wakeup_granularity_ns=4000000  # 4ms — background can't easily steal from game
kernel.sched_latency_ns=12000000            # 12ms — still responsive, doesn't over-preempt
kernel.sched_autogroup_enabled=1
```

### Context switch investigation
When CS seems high:
1. Measure rate: `grep "^ctxt" /proc/stat` over a 3-second interval
2. Find top consumers: check `/proc/*/status` for voluntary + nonvoluntary counts
3. **High voluntary CS**: Normal for Proton/Wine (every Windows API call → 2+ CS via wineserver)
4. **High involuntary CS**: The kernel is forcing the process off CPU — find the source:
   - GPU IRQs on same core (check `cat /proc/interrupts | grep nvidia`)
   - Scheduler preemption (check if `sched_min_granularity_ns` is too low)
   - Compare involuntary CS with GPU interrupt count on that core

## Kernel Boot Params (non-isolcpus approaches)

For P-cores free from interrupts WITHOUT isolcpus (which hides cores from the scheduler):

```
# rcu_nocbs — offloads RCU callbacks from P-cores. Works without isolcpus.
# nohz_full — adaptive tickless. PARTIALLY works without isolcpus; timer ticks
#             return when tasks migrate onto the core.
```

`nohz_full` WITHOUT `isolcpus` is **documented as requiring isolcpus** — the kernel will enter adaptive-tick mode when the core has 1 task, but exit it when a second task arrives. On a busy workstation where background tasks (Chrome, Steam) constantly touch P-cores, `nohz_full` without `isolcpus` achieves almost nothing. It's also harmless — the kernel falls back to periodic ticks gracefully.

`rcu_nocbs` OFFLOADS RCU callbacks unconditionally, with or without isolcpus. This provides a small but real benefit — RCU cleanup runs on E-cores instead of P-cores.

**Display refresh rate verification note:**
`kscreen-doctor -o` shows modes with `!` (current) and `*` (preferred) markers. These markers can be misleading on Wayland + NVIDIA — don't assume `!` means the display is actually running at that refresh rate. Verify via KWin's internal state or check Display Settings in System Settings. If VRR is enabled and the monitor seems stuck at 60Hz, the kscreen-doctor output may be reporting the base EDID mode rather than the active VRR rate.

The REAL solution for gaming on a hybrid workstation:
1. Move ALL IRQs to E-cores via pin-irqs script
2. Fix scheduler values to not thrash
3. Use gamemode for priority boost (`renice=-5`, `softrealtime=auto`)
4. Optionally: `taskset -c 0-7 gamemoderun %command%` per-game (no reboot needed)

## NVIDIA + Wayland Performance

### Known issues
- GSP firmware on GB206 (RTX 5060 Ti) IS available (at `/lib/firmware/nvidia/gb206/gsp/`)
- `NVreg_EnableGpuFirmware=1` enables GPU firmware offloading, reducing driver CPU overhead
- NVIDIA IRQ vectors use MSI-X — each new `nvidia` entry in `/proc/interrupts` is a separate vector
- On driver 595+, Wayland with `GBM_BACKEND=nvidia-drm` is the correct backend

### Environment variables (verified working for KDE 6 + NVIDIA 595+)
```
GBM_BACKEND=nvidia-drm
__GLX_VENDOR_LIBRARY_NAME=nvidia
KWIN_DRM_DISABLE_TRIPLE_BUFFERING=1     # KDE6 var (NOT KWIN_TRIPLE_BUFFER which is KDE5)
KWIN_DRM_ALLOW_TEARING=1
__GL_MaxFramesAllowed=1
__GL_SYNC_TO_VBLANK=0
__GL_VRR_ALLOWED=1
```

### GPU Presentation Latency: Intel IOMMU

Intel IOMMU (`intel_iommu=on`) adds DMA address translation to every GPU buffer exchange — every Wayland frame submission, every EGL swap, every texture upload. On a desktop with no VM passthrough (no VFIO), this is pure overhead with no benefit.

**Impact on input latency:** The keyboard-to-display pipeline requires the compositor to present a new frame after every keystroke. Each frame goes through: Alacritty → EGL swap → KWin composition → NVIDIA kernel driver → PCIe DMA. IOMMU wraps every DMA transaction with a translation + permission check. This adds ~0.1-0.5ms per frame.

**Fix:** Remove `intel_iommu=on` from kernel cmdline. The NVIDIA driver talks directly to the GPU via PCIe BAR — it doesn't need IOMMU translation. In fact, on RTX 5000 series (GB206/Blackwell), IOMMU can trigger NVDEC0 GPU MMU faults (NVIDIA Xid 31) because the IOMMU page tables conflict with the GPU's internal VA space manager.

```sh
# GRUB
sudo sed -i 's/ intel_iommu=on,igfx_off//g; s/intel_iommu=on,igfx_off //g; s/intel_iommu=on,igfx_off//g' /etc/default/grub
sudo grub-mkconfig -o /boot/grub/grub.cfg

# systemd-boot
sudo sed -i 's/ intel_iommu=on,igfx_off//g; s/intel_iommu=on,igfx_off//g' /boot/loader/entries/*.conf
```

### Pitfalls
- `KWIN_TRIPLE_BUFFER=0` is a KDE5 var — does nothing on KDE6. The KDE6 equivalent is `KWIN_DRM_DISABLE_TRIPLE_BUFFERING=1`
- `nvidia-settings -a GPUPowerMizerMode=2` may silently fail on Wayland — use modprobe `NVreg_RegistryDwords` instead
- `DXVK_ASYNC=1` is obsolete on DXVK 2.x+ — use `dxvk.conf` with `dxvk.enableAsync = True`
- `LIBVA_DRIVER_NAME=nvidia` vs `nvidia_vulkan` are different backends — align them across all config files
- **VRR flicker on NVIDIA Wayland** — `VrrPolicy=Always` causes constant monitor flickering on desktop because the refresh rate fluctuates with every compositor render change. Fix: set `VrrPolicy=FullscreenOnly`. Apply via: `kwriteconfig5 --file kwinrc --group Compositing --key VrrPolicy FullscreenOnly` then reconfigure KWin or log out/in.
- **Intel IOMMU causes NVDEC0 GPU MMU faults on RTX 5000 series** — Chrome's hardware video decode triggers NVIDIA Xid 31 GPU MMU faults when `intel_iommu=on` is set. The IOMMU page tables cache structure conflicts with the GPU's internal VA space manager for NVDEC0. Removing `intel_iommu=on` resolves both the MMU faults and the associated DMA translation overhead. Disable Chrome's `--disable-accelerated-video-decode` as a workaround if IOMMU must stay on for VM passthrough.

## Keyboard Input Latency Diagnosis

End-to-end investigation methodology for diagnosing why keyboard input feels laggy on a Linux desktop (especially Alacritty/Kitty/foot terminals on Wayland + NVIDIA).

### Trigger

Use this when the user reports:
- "Keyboard feels laggy" or "input latency is high in terminal"
- Alacritty/terminal specifically has worse latency than other apps
- Key presses take perceptible time to appear on screen
- User has already checked the easy things (no input method, no heavy compositor effects)

### The Full Input Pipeline

Every keystroke must travel through approximately 8 hops from hardware to visible character:

```
Keyboard HW → USB HID → kernel input subsystem → Wayland compositor (KWin) →
wl_keyboard protocol → terminal event loop → terminal render → EGL swap →
compositor composition → NVIDIA DRM driver → Display
```

Diagnose layer by layer. Do NOT skip any layer.

### Layer 1 — Hardware Path (Keyboard + USB)

```bash
# 1a. Identify keyboard device path and USB controller
ls -la /dev/input/by-path/*-event-kbd
# Look for pci-0000:xx:xx.x-usb-...-event-kbd — the USB path tells you the controller

# 1b. Get USB vendor/product ID and HID polling interval
sudo lsusb -v -d <vendor:product> 2>/dev/null | grep -E '(bInterval|bcdUSB|HID Device)'
# bInterval=1 means 1ms USB interrupt interval (optimal)
# bInterval >1 means >1ms polling (adds baseline latency)

# 1c. Check kernel USB HID polling override
cat /sys/module/usbhid/parameters/kbpoll
# Should be 1 (1ms) — set via boot param usbhid.kbpoll=1

# 1d. Check USB autosuspend status on keyboard port
for dev in /sys/bus/usb/devices/*/product; do
  product=$(cat $dev 2>/dev/null)
  dir=$(dirname $dev)
  if [ -e "$dir/power/autosuspend" ]; then
    echo "$product: autosuspend=$(cat $dir/power/autosuspend)"
  fi
done
# autosuspend=2 means: 2s idle → USB port suspends → 3-10ms resume latency on next keypress
# autosuspend=-1 means disabled (no resume delay)
# autosuspend=0 means immediate suspend (worst for input)
```

### Layer 2 — IRQ Affinity (Where USB Interrupts Get Processed)

USB keyboard interrupts are handled by the xHCI USB controller's IRQ. If that IRQ lands on an E-core or shares a core with GPU interrupts, latency increases.

```bash
# 2a. Find USB controller IRQ numbers
cat /proc/interrupts | grep xhci_hcd
# Note the IRQ numbers (first column)

# 2b. Check which CPUs handle them
for irq in $(grep "xhci_hcd" /proc/interrupts | awk '{print $1}' | tr -d ':'); do
  echo "IRQ $irq ($(cat /proc/irq/$irq/actions 2>/dev/null)): CPU $(cat /proc/irq/$irq/smp_affinity_list 2>/dev/null)"
done

# 2c. Critical check: USB IRQ on same core as GPU IRQ?
cat /proc/interrupts | grep -E "nvidia|xhci_hcd" | awk '{print $1, $(NF-1), $NF}'
# If USB and NVIDIA share CPUs → GPU interrupts delay USB processing
```

**Key signal:** USB IRQ on an E-core (CPUs 12-19 on Arrow Lake 265K) adds inter-core latency vs. a P-core. USB IRQ sharing a core with NVIDIA GPU IRQ causes input latency spikes under GPU load.

```bash
# 2d. Fix: pin USB IRQ to a dedicated P-core
echo 2 | sudo tee /proc/irq/<N>/smp_affinity_list
# Make permanent via systemd service (see references/keyboard-input-latency-pipeline.md)
```

### Layer 3 — C-State Exit Latency

When the system is idle and the keyboard hasn't been touched, the CPU can enter deep package C-states. A keystroke IRQ must wake the CPU first.

```bash
# 3a. Check current max C-state
cat /sys/module/intel_idle/parameters/max_cstate

# 3b. Check C-state latencies
for state in /sys/devices/system/cpu/cpu0/cpuidle/state*/latency; do
  echo "$(basename $(dirname $state)): $(cat $state) us"
done

# 3c. Check C-state usage on the USB IRQ core (replace N with actual CPU)
cpupower -c N idle-info 2>/dev/null | head -20
```

**Key signal:** If `max_cstate >= 6` and the system was idle before the keystroke, the CPU exits ~500-1000µs of deep sleep before processing the IRQ. On top of USB autosuspend resume (3-10ms), this compounds.

**Fix:** `echo 4 | sudo tee /sys/module/intel_idle/parameters/max_cstate` or add `intel_idle.max_cstate=4` to kernel cmdline.

### Layer 4 — Compositor/Display Latency Budget

The Wayland compositor controls frame timing. At 165Hz, each frame is ~6ms. The compositor adds at minimum 1 frame of buffering.

```bash
# 4a. KWin compositor settings
grep -A20 '\[Compositing\]' ~/.config/kwinrc

# 4b. Verify compositor type
qdbus6 org.kde.KWin /Compositor org.freedesktop.DBus.Properties.Get \
  org.kde.kwin.Compositing compositingType

# 4c. Monitor current resolution and refresh
kscreen-doctor -o | grep -E "Modes:|Vrr|@"
```

**Signals you want:** `LatencyPolicy=LatencyLow`, `AllowTearing=true`, `KWIN_DRM_DISABLE_TRIPLE_BUFFERING=1`, triple buffering disabled at the env level.

### Layer 5 — Application-Specific Path

The terminal emulator adds its own latency on top of the compositor pipeline.

```bash
# 5a. Check whether terminal runs native Wayland or XWayland
cat /proc/$(pgrep -x alacritty | head -1)/environ 2>/dev/null | tr '\0' '\n' | \
  grep -E '^(WAYLAND_DISPLAY|DISPLAY)'
# If WAYLAND_DISPLAY is set → native Wayland (good)
# If only DISPLAY=:0 → running under XWayland (adds extra hop)

# 5b. Check terminal renderer
# Alacritty: GLES2 on OpenGL 3.3 (check binary strings)
strings /usr/bin/alacritty 2>/dev/null | grep -E 'renderer|gles|opengl' | sort -u

# 5c. Check scheduling priority
chrt -p $(pgrep -x alacritty | head -1)
# SCHED_OTHER = normal priority, can be preempted by any RR/FIFO process (including KWin)

# 5d. Check thread model — input and render on same thread?
ps -T -p $(pgrep -x alacritty | head -1) 2>/dev/null
# If main thread handles both input + rendering → a slow render blocks input
```

### Summary: Five-Fix Approach

When all layers are diagnosed, these are the five permanent fixes in priority order:

| # | Fix | Latency Saved | How |
|---|---|---|---|
| 1 | USB IRQ → P-core | 0.5-2ms | systemd service pinning xhci_hcd IRQ to a P-core |
| 2 | Limit C-states | 0.1-1ms | `intel_idle.max_cstate=4` in kernel cmdline |
| 3 | USB autosuspend off | 3-10ms intermittent | udev rule setting `power/autosuspend=-1` for keyboard by vendor:product ID |
| 4 | Remove Intel IOMMU | 0.1-0.5ms | Remove `intel_iommu=on` from kernel cmdline (also fixes NVDEC0 faults) |
| 5 | Raise terminal priority | 0.1-1ms under load | `nice -n -5` via modified .desktop file or systemd user service |

See the reference file for exact commands: `references/keyboard-input-latency-pipeline.md`

## USB HID Polling Optimization (1000Hz Mouse/Keyboard)

The most overlooked latency fix for USB input devices. Even with `usbhid.mousepoll=1` and `usbhid.kbpoll=1` in kernel cmdline, the device's own USB `bInterval` and libinput's hwdb can override the effective polling rate.

### Three-Layer USB HID Polling Architecture

```
Layer 3 — Hardware bInterval (device-advertised)
  ↓
Layer 2 — Kernel usbhid.mousepoll/kbpoll (kernel fallback cap)
  ↓
Layer 1 — libinput hwdb MOUSE_POLL quirk (effective override)
```

**Each layer can independently cap the final rate.**

| Layer | What controls it | How to verify | How to fix |
|-------|-----------------|---------------|------------|
| 3 — Device bInterval | USB descriptor from manufacturer | `sudo lsusb -v -d <VID:PID> \| grep bInterval` (1=1ms, 6=~4ms) | Hardware-limited; gaming devices typically have bInterval=1 already |
| 2 — Kernel usbhid.mousepoll/kbpoll | Kernel params | `cat /sys/module/usbhid/parameters/mousepoll` | `usbhid.mousepoll=1 usbhid.kbpoll=1` in GRUB |
| 1 — hwdb MOUSE_POLL | udev hwdb files | `sudo libinput quirks list` or check `/etc/udev/hwdb.d/` | hwdb entry `MOUSE_POLL=1` per VID:PID |

### The hwdb Quirk (Layer 1 — Most Important)

Without hwdb, libinput assumes the device runs at its advertised bInterval (typically 125-250Hz for most peripherals). The hwdb file overrides this at the libinput level:

```bash
# /etc/udev/hwdb.d/71-corsair-polling.hwdb
# Corsair Katar Pro XT — 1000Hz
evdev:input:b0003v1b1Cp1bac* MOUSE_POLL=1

# BY Tech Thor 230 — 1000Hz (mouse + keyboard on same dongle)
evdev:input:b0003v331Ap5020* MOUSE_POLL=1
```

Apply:
```bash
sudo systemd-hwdb update && sudo udevadm trigger
```
No reboot needed. Immediate effect.

### The usbhid.quirks Kernel Param (Layer 2 Reinforcement)

`usbhid.quirks=0xVID:0xPID:0x40` — the `0x40` flag = `HID_QUIRK_ALWAYS_POLL`:

- **Without quirks**: USB device enters autosuspend when idle. On first input: resume USB (1-3ms wake latency), batch events, process. First few movement deltas lost.
- **With quirks 0x40**: Device never suspended, never enters low-power mode. Events flow at full rate with zero wake latency.
- **With `usbcore.autosuspend=-1`**: Global USB never sleeps. Complements per-device quirks.

```ini
# GRUB_CMDLINE_LINUX_DEFAULT append:
usbhid.quirks=0x1b1c:0x1bac:0x40,0x331a:0x5020:0x40 usbcore.autosuspend=-1
```

### Total Effect

| Config | Effective Poll Rate | Wake Latency | Micro-Gaps |
|--------|-------------------|-------------|------------|
| Default (no hwdb, no quirks) | 125-250Hz (4-8ms) | 3-10ms on first input | Yes (drop first 2-3 events after idle) |
| hwdb only | 1000Hz (1ms) | 3-10ms on first input | Yes |
| hwdb + quirks + autosuspend | 1000Hz (1ms) | 0ms (always active) | No |

### Workflow — Adding a New USB Device

```bash
# 1. Find VID:PID
lsusb | grep -i "device_name"

# 2. Find the event device path
ls -la /dev/input/by-id/*"device_name"*

# 3. Verify current bInterval (need sudo)
# sudo lsusb -v -d <VID:PID> | grep bInterval

# 4. Add hwdb entry
sudo tee -a /etc/udev/hwdb.d/71-custom-polling.hwdb << EOF
evdev:input:b0003v<VID>p<PID>* MOUSE_POLL=1
EOF

# 5. Apply
sudo systemd-hwdb update && sudo udevadm trigger

# 6. Verify effective polling with evtest (on a mouse or keyboard event node)
# Watch event timestamps — should show ~1ms deltas during fast movement
sudo evtest --grab /dev/input/by-id/usb-...-event-mouse
# Look for sub-2ms deltas between consecutive POINTER_MOTION events during fast sweep
```

## Output Style Preference

The user for this system prefers **commands-first, terse output**. Present the exact command(s) before any explanation. The user will ask if they need clarification. When sharing tuning recommendations:

1. Show the command first: `sudo cat /sys/...` not "Let me check your current..."
2. Show the actual output next
3. Only explain if the result is unexpected
4. Avoid multi-paragraph analysis — let the numbers speak

This applies to ALL tuning/debugging output for this user. "Show me the command and its result, then I'll ask for more" is the expected interaction pattern.

## Workstation + Desktop + Gaming Comprehensive Tune-Up

When the user asks for "all tweaks" or a complete system tune-up covering workstation, desktop responsiveness, AND gaming, use the following layered approach. Each layer is a self-contained batch of copy-paste commands.

### The Nine-Layer Tuning Stack

| Layer | Focus | Impact |
|-------|-------|--------|
| 1 — Kernel & Scheduler | linux-zen/cachyos, scx_lavd, preempt=full | Every interaction |
| 2 — Memory & VM | swappiness, huge pages, ZRAM | Large workloads |
| 3 — Storage & I/O | NVMe scheduler, noatime, TRIM | Storage responsiveness |
| 4 — KDE Compositor | triple buffering, VRR, animation speed | Desktop feel |
| 5 — NVIDIA Compute | persistence mode, PowerMizer, CUDA env | GPU throughput |
| 6 — CPU Governor | schedutil/performance, auto-cpufreq | Power/performance |
| 7 — PipeWire Audio | quantum tuning, WirePlumber config | Audio latency |
| 8 — Service Reduction | bluetooth, cups, indexing, journal | More RAM/CPU |
| 9 — Compiler & Build | makepkg, ccache, RAM-based build dir | Faster compiles |

Execute layers in order. Each layer is independent — no batch-ordering dependencies.

See `references/workstation-desktop-gaming-tuning-2026.md` for the full command reference.

### WirePlumber 0.5 vs 0.4 Config — Known Pitfall

WirePlumber **0.5+** uses `.conf` files in `wireplumber.conf.d/` with SPA-JSON syntax, NOT Lua tables in `main.lua.d/`.

| Version | Config Dir | Syntax | Example |
|---------|-----------|--------|---------|
| 0.4.x | `main.lua.d/` | Lua `table.insert(alsa_monitor.rules, ...)` | Old (broken on 0.5+) |
| **0.5.x** | **`wireplumber.conf.d/`** | **`monitor.audio.rules = [ { matches = [...], actions = {...} } ]`** | **Current** |

**Wrong (0.4 syntax, will error on 0.5):**
```lua
-- ~/.config/wireplumber/main.lua.d/51-chrome-low-latency.lua
rule = {
  matches = [ { { "application.name", "equals", "chrome" } } ],
  apply_properties = { ["node.quantum"] = 256 },
}
table.insert(alsa_monitor.rules, rule)
```

**Correct (0.5 syntax):**
```ini
# ~/.config/wireplumber/wireplumber.conf.d/51-chrome-quantum.conf
monitor.audio.rules = [
  {
    matches = [ { application.name = "Google Chrome" } ]
    actions = { update-props = { node.quantum = 256 } }
  }
]
```

Always check `wireplumber --version` first to determine which API to use. If version ≥ 0.5, use `.conf` in `wireplumber.conf.d/`.

### LACTD Polling — Micro-Stutter Source

LACTD (Linux GPU Control Daemon) polls GPU sensors for fan curves every `interval_ms` and reapplies the full config every `apply_settings_timer` seconds. Default values (500ms interval, 5s reapply) cause periodic PCIe register reads/writes that can manifest as micro-stutters in games.

```bash
# Check current config
cat /etc/lact/config.yaml | grep -E 'interval_ms|apply_settings_timer'

# Saner values for gaming (2s polling, 30s reapply)
# Edit /etc/lact/config.yaml:
#   interval_ms: 2000
#   apply_settings_timer: 30
sudo nano /etc/lact/config.yaml
sudo systemctl restart lactd
```

If you're not doing dynamic fan control at all, just stop lactd entirely:
```bash
sudo systemctl disable --now lactd.service
```

### nvidia_drm fbdev=1 on Wayland — Wasted VRAM

The `nvidia_drm` kernel module with `fbdev=1` allocates a shadow framebuffer in VRAM and runs a console emulator (`/dev/fb0`) that nobody reads on a Wayland-only desktop. Every frame the emulator polls adds unnecessary GPU-CPU sync traffic.

Check:
```bash
cat /sys/module/nvidia_drm/parameters/fbdev  # 1 = enabled
ls -la /dev/fb*  # /dev/fb0 exists
```

Fix on Wayland-only systems:
```bash
# Set fbdev=0 in modprobe.d
echo 'options nvidia_drm modeset=1 fbdev=0' | sudo tee /etc/modprobe.d/nvidia-drm.conf
sudo mkinitcpio -P && reboot
```

### Pitfalls

### DON'T Write System Files During Investigation
- **`MOUSE_POLL=1` also affects keyboards** on multi-interface dongles (e.g., a wireless mouse+kb combo may have one USB interface for both). Apply the quirk to the mouse's event path and the keyboard event path on the same device.
- **usbhid.mousepoll/kbpoll are kernel FALLBACKS**, not overrides. If the device's firmware-advertised bInterval is 6 (4ms), and no hwdb entry exists, the kernel respects the device's value even if mousepoll=1.
- **`power-profiles-daemon` silently overrides CPU governor**. Even with `cpufreq.default_governor=performance` in GRUB, PPD can change it to `powersave` at any time. **Always disable PPD** on a low-latency workstation: `sudo systemctl disable --now power-profiles-daemon`. Verify: `cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor` shows `performance`.
- **GRUB edits can silently fail to persist** when:
  1. Running `grub-mkconfig` but the output goes to the wrong path (check `grub-mkconfig -o /boot/grub/grub.cfg` vs systemd-boot's `/boot/loader/entries/`)
  2. A kernel update regenerates grub.cfg from the current grub defaults, overwriting manual changes
  3. Editing `GRUB_CMDLINE_LINUX_DEFAULT` vs `GRUB_CMDLINE_LINUX` (they concatenate at boot — missing params may be in the wrong line)
  **Safest workflow**: edit `/etc/default/grub`, then run `sudo grub-mkconfig -o /boot/grub/grub.cfg`, then **reboot and verify**: `cat /proc/cmdline | grep <param>`. Do not rely on the GRUB file alone.
- **xinput does NOT work on Wayland**. For input debugging on KDE Wayland, use `sudo libinput debug-events` or `sudo evtest`. `xinput list-props` returns nothing for Wayland devices.

### Reference file

See `references/usb-hid-polling-1000hz.md` for session-specific reproduction commands and a real-world Corsair Katar Pro XT + BY Tech Thor 230 configuration.

## Network Latency Tuning

### WiFi-specific
- **Modprobe** `iwlwifi power_save=0 uapsd_disable=1` sets driver-level power saving
- **Runtime** `iw dev wlpXXX set power_save off` is a SEPARATE control from modprobe
- Both must be set for lowest WiFi latency
- Default qdisc is `noqueue` — `fq_codel` adds bufferbloat protection

### TCP tuning for gaming
```ini
net.ipv4.tcp_congestion_control=bbr
net.core.default_qdisc=fq
net.ipv4.tcp_notsent_lowat=131072     # Allows send without ACK wait
net.ipv4.tcp_fastopen=3
```
