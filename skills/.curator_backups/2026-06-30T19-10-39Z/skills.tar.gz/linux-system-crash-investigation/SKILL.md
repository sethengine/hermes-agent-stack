---
name: linux-system-crash-investigation
description: >
  Systematic investigation of unexplained system crashes and reboots on Linux.
  Covers journalctl boot analysis, GPU/driver fault hunting (NVIDIA Xid, AMD GPU),
  IRQ affinity debugging, kernel parameter forensics, and hardware watchdog checks.
  Use when user reports system restarting/crashing unexpectedly.
---

## Linux System Crash & Reboot Investigation

### Phase 1: Boot History & Crash Signature

```bash
# Get full boot timeline
journalctl --list-boots

# Check last boot for clean shutdown
journalctl -b -1 --no-pager | grep -E 'systemd-shutdown|Journal stopped|SIGTERM'

# Absence = hard crash (no clean shutdown logged)

# Check for kernel panic/oops in any recent boot
journalctl -b -1 -k --no-pager | grep -iE 'panic|oops|Call Trace|BUG|lockup|hung_task|rcu.*stall'

# Check for segfaults/coredumps in userspace
journalctl -b -1 --no-pager | grep -iE 'segfault|SIGSEGV|dumped core|oom.kill'
```

### Phase 2: GPU Fault Hunting (NVIDIA)

```bash
# Xid errors = GPU hardware faults
journalctl -b -1 -k --no-pager | grep 'NVRM: Xid'
# Also check current boot and older boots
journalctl -b 0 -k | grep Xid
journalctl -b -2 -k --no-pager | grep Xid

# Decode Xid codes - see references/nvidia-xid-codes.md
# Common patterns:
#   Xid 31: MMU Fault - GPU page table fault, often NVDEC0 (video decoder)
#   Xid 79: GPU has fallen off the bus (PCIe issues)
#   Xid 45: Preemptive channel removal
```

### Phase 3: IRQ Affinity & CPU Isolation Interaction

```bash
# Check which CPUs are isolated vs housekeeping
cat /proc/cmdline | tr ' ' '\n' | grep -E 'isolcpus|nohz_full|rcu_nocbs'
cat /sys/devices/system/cpu/nohz_full
cat /sys/devices/system/cpu/isolated

# Full IRQ-to-CPU mapping with classification
# Uses scripts/check_irq_affinity.py — classifies by isolated/housekeeping
python3 scripts/check_irq_affinity.py

# Key check: are GPU/USB/NVMe IRQs landing on housekeeping cores
# or isolated cores? The GPU IRQ handler needs timer ticks enabled.
```

### Phase 4: Kernel Parameter Forensics

```bash
# Compare cmdline across recent boots
journalctl -b -1 -k --no-pager | grep 'Command line'
journalctl -b -2 -k --no-pager | grep 'Command line'
cat /proc/cmdline  # current boot

# Key parameters that affect stability:
#   pcie_aspm=off/pcie_aspm.policy=performance  -- aggressive PCIe
#   pci=pcie_bus_perf,pcie_ports=native         -- native PCIe handling
#   intel_iommu=on                              -- GPU DMA through IOMMU
#   iommu=pt                                    -- IOMMU passthrough mode
#   nvidia_drm.modeset=1,nvidia_drm.fbdev=1    -- NVIDIA kernel modesetting
```

### Phase 5: Watchdog Configuration

```bash
# Hardware watchdog
ls -la /dev/watchdog*
dmesg | grep -iE 'watchdog|iTCO|wdt'

# Kernel watchdog
cat /proc/sys/kernel/nmi_watchdog
cat /proc/sys/kernel/softlockup_panic
cat /proc/sys/kernel/hardlockup_panic

# Systemd watchdog
grep -r 'RuntimeWatchdogSec\|WatchdogSec' /etc/systemd/

# If iTCO_wdt is blacklisted, no hardware watchdog → hung system stays hung
```

### Phase 6: Frame the Crash Timeline

Reconstruct the exact sequence:
1. When was the last normal log entry before silence?
2. What was the last process running? Steam? Chrome? pamac?
3. What GPU errors preceded the crash (if any)?
4. Was there an intervening event (scxctl, sudo, service start)?
5. What changed in the kernel cmdline between the crash boot and the next boot?

## Common Root Causes Found on This System

1. **libva-nvidia-driver + Chrome VA-API → NVDEC Xid 31**
   - Chrome uses `VaapiOnNvidiaGPUs`, `VaapiIgnoreDriverChecks`
   - Triggers NVDEC0 MMU faults
   - Fix: disable Chrome GPU video decode or remove `VaapiIgnoreDriverChecks`

2. **isolcpus on P-cores forcing Chrome onto E-cores**
   - Creates contention between GPU IRQs and Chrome on same slow cores
   - Makes post-fault recovery harder

3. **iTCO_wdt blacklisted → no auto-reboot on hang**
   - `modprobe.blacklist=iTCO_wdt` removes hardware watchdog
   - Hung GPU = system stays dead until manual reset

## Pitfalls

- **Don't execute fixes without explaining first.** User wants to understand before changes are made.
- `isolcpus=managed_irq` allows managed IRQs (NVMe MSI-X) to target isolated CPUs — usually undesirable.
- `nohz_full` on the SAME cores as GPU IRQs would delay interrupt handling, but GPU IRQs usually go to separate (E-core) CPUs.
- `preempt=voluntary` prevents kernel from preempting hung GPU threads — `preempt=full` allows breaking deadlocks.
