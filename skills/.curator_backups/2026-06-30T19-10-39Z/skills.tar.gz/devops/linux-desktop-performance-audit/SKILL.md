---
name: linux-desktop-performance-audit
description: "Systematic performance audit of Linux desktops — hardware, kernel, GPU (especially NVIDIA + Wayland), compositor, environment variables, storage, and VM tunables. Cross-references findings with current community research and produces prioritized recommendations."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [linux, performance, tuning, nvidia, wayland, gpu, kernel, audit]
    related_skills: [systematic-debugging, internet-research, last30days]
---

# Linux Desktop Performance Audit

## When to Use

Trigger when the user asks about:
- Improving desktop/game/GPU performance on Linux
- Stuttering, latency, or FPS drops on Wayland with NVIDIA
- Checking their system for missed optimization opportunities
- "What tweaks should I apply" or "audit my config"
- Comparing their setup against community best practices
- Diagnosing whether their kernel/GPU/env config is optimal
- Any combination of {Linux, Wayland, NVIDIA, performance, tweaks, tuning}

Also fire proactively when the user reveals their system stack (distro + GPU + display server) and the session context involves performance — many users don't know what they're missing.

## Core Principle

Do NOT guess at tweaks. **Inspect first, then match findings to community data.** The most valuable output is a prioritized list where each recommendation cites: (a) the measured current state, (b) what the recommended state should be, and (c) the effort/impact tradeoff.

## Round-Based Reporting Pattern

Do NOT dump every finding at once. Present in rounds:

- **Round 1** = ~5-7 highest-impact findings. Let the user act on them.
- **Round 2** = medium-impact polish items. Offer to go deeper.
- **Round 3+** = edge cases, conflicts, tiny overhead items. Only when user asks "more" or "find untouched configs."

This prevents overwhelming the user and lets them control depth. Respond to "find more" / "a more" / "keep going" by going a layer deeper each time.

Each round's findings should cover a new layer (HW → kernel → GPU → storage → audio → network → desktop → services) rather than re-iterating the same layer with more detail.

## The Layered Audit (run in parallel batches)

Run ALL of these before synthesizing recommendations. Each layer is independent, so fire the gather commands in parallel batches.

### Layer 1: Hardware Inventory

```
echo "=== CPU ==="
cat /proc/cpuinfo | grep -m1 "model name"
cat /proc/cpuinfo | grep -c "^processor"
echo "=== GPU ==="
lspci | grep -i "vga\|3d\|nvidia"
echo "=== RAM ==="
free -h
echo "=== Disks ==="
lsblk -d -o NAME,SIZE,ROTA,MOUNTPOINT,MODEL
echo "=== NUMA ==="
lscpu | grep -i numa
```

Key signals: CPU generation (check for SMT/HT support), GPU architecture and VRAM, available RAM vs used, NVMe vs SATA, single vs multi-NUMA.

### Layer 2: Kernel + Boot Configuration

```
echo "=== Kernel ==="
uname -a
echo "=== Boot params ==="
cat /proc/cmdline
echo "=== PREEMPT model ==="
cat /sys/kernel/realtime 2>/dev/null || echo "not RT"
uname -a | grep -o "PREEMPT[^ ]*"
echo "=== CPU governor + frequency ==="
cat /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor | sort | uniq -c
cat /sys/devices/system/cpu/cpu*/cpufreq/energy_performance_preference 2>/dev/null | sort -u
echo "=== intel_pstate ==="
cat /sys/devices/system/cpu/intel_pstate/status 2>/dev/null
echo "=== THP ==="
cat /sys/kernel/mm/transparent_hugepage/enabled
cat /sys/kernel/mm/transparent_hugepage/defrag
```

**Known pitfalls:**
- Intel Arrow Lake (Core Ultra 200 series) P-cores do NOT have Hyper-Threading. `smt/active = 0` is correct and expected. Do NOT flag this as an issue.
- `intel_pstate` "powersave" governor in `active` mode means "dynamic scaling from high baseline," NOT "low power." This is the old intel_pstate naming convention. Check `energy_performance_preference` instead — if it says "performance," the system IS in performance mode. The label "powersave" is misleading but correct behavior.
- `cpufreq.default_governor=performance` may not take effect if KDE/systemd power profiles override it. Check `powerprofilesctl get` or current scaling_governor in /sys.
- Kernel 7.0+ (Manjaro): PREEMPT_DYNAMIC is supported. `preempt=voluntary` is Manjaro default. `preempt=full` gives lower worst-case scheduling latency for desktop.
- **`sched_autogroup_enabled=1` (default) causes interactive task latency.** On desktop systems, autogroup groups tasks by TTY session. When alt-tabbing between sessions, the kernel adjusts group priorities, causing a priority cascade that generates rescheduling IPIs. For dedicated desktop/gaming use, set `kernel.sched_autogroup_enabled=0`.
- **`timer_migration=1` (default) disrupts nohz_full on P-cores.** Timer migration allows timers to bounce between CPUs. On a system with `nohz_full=1-7`, this means timers can land on quiet P-cores, breaking adaptive tickless behavior. Set `kernel.timer_migration=0` to keep timers on their originating CPU (typically E-cores).

### Layer 3: NVIDIA GPU + Driver

```
echo "=== Driver ==="
nvidia-smi --query-gpu=name,driver_version,power.limit,temperature.gpu,utilization.gpu,memory.total,memory.used --format=csv,noheader
echo "=== Clocks ==="
nvidia-smi -q -d CLOCK | head -25
echo "=== Power ==="
nvidia-smi -q -d POWER | head -15
echo "=== Persistence ==="
systemctl is-active nvidia-persistenced 2>/dev/null
echo "=== Kernel modules ==="
lsmod | grep -i nvidia
echo "=== Modprobe config ==="
cat /etc/modprobe.d/nvidia*.conf 2>/dev/null
echo "=== GSP firmware files ==="
ls /lib/firmware/nvidia/ 2>/dev/null | sort
echo "=== OpenGL ==="
glxinfo -B 2>/dev/null | head -15
echo "=== Vulkan ==="
vulkaninfo --summary 2>/dev/null | grep -i "driver\|deviceName\|apiVersion" | head -5
```

**Key signals and known pitfalls:**
- **GSP firmware** (`NVreg_EnableGpuFirmware`): Check whether firmware exists for the GPU's architecture in `/lib/firmware/nvidia/`. If a directory like `gb206` exists (Blackwell) AND `NVreg_EnableGpuFirmware=0` is set, the firmware is being disabled despite being available. This increases driver CPU overhead. For Blackwell (RTX 5000) cards with driver 595+, enabling GSP firmware (`=1`) can improve display management and power state handling. For Ada (RTX 4000), GSP firmware historically caused Wayland issues on older drivers (<545) — check the specific driver version. **Always verify firmware files exist before suggesting enable.**
- **Power limit**: Check default vs current vs max via nvidia-smi. The max power limit gives ~3-5% sustained clock headroom. Suggest raising to max only if user confirms GPU-bound workloads.
- **PowerMizer**: `PowerMizerLevel=0x2` in modprobe RegistryDwords = "maximum performance" (always runs at max clocks under load). `0x1` = adaptive, `0x3` = auto. Verify what's set.
- **Resizable BAR**: `NVreg_EnableResizableBar=1` should be set for RTX 3000+ cards on modern UEFI systems.
- **DXVK_ASYNC=1**: This env var was removed from DXVK 2.0+ (mid-2024). If the user has it set and is on DXVK 2.x, the flag is a no-op. Check which DXVK version is installed. Do NOT assume it's still beneficial.
- Check for commented-out conflicting options (e.g., `#__GL_THREADED_OPTIMIZATIONS=1` commented but the env var may be set elsewhere).

### Layer 4: Wayland / Compositor Config

```
echo "=== Session type ==="
echo "XDG_SESSION_TYPE: ${XDG_SESSION_TYPE:-not set}"
loginctl show-session $(loginctl | grep $(whoami) | awk '{print $1}') -p Type 2>/dev/null
echo "=== Compositor version ==="
kwin_wayland --version 2>/dev/null
echo "=== KWin config (compositing) ==="
grep -A20 '\[Compositing\]' ~/.config/kwinrc 2>/dev/null
echo "=== Environment.d files ==="
cat ~/.config/environment.d/*.conf 2>/dev/null
```

**Key signals:**
- `LatencyPolicy=LatencyLow` in kwinrc — optimal for gaming. `LatencyNormal` leaves headroom for compositor effects.
- `VrrPolicy=Always` — good for VRR monitors. `Never` = no VRR. `Automatic` = only fullscreen.
- `AllowTearing=true` — enables unthrottled presentation. Combined with `__GL_SYNC_TO_VBLANK=0`, this gives tear-free VRR or tearing with vsync off.
- `UnredirectFullscreen=true` — skips compositing for fullscreen windows (lowest latency).
- Check `MOZ_ENABLE_WAYLAND=1` for Firefox, `ELECTRON_OZONE_PLATFORM_HINT=wayland` for Electron apps. If these are set to 0 or commented out but the user is on Wayland, flag it.

### Layer 5: Environment Variables

Check ALL of these locations:
- `/etc/environment` (system-wide)
- `~/.profile`, `~/.bashrc`, `~/.zshrc` (shell)
- `~/.config/environment.d/*.conf` (systemd user session — IMPORTANT: this is where Plasma/KDE picks up env vars for Wayland-session apps)
- Any `.env` files in shell configs

**Game/GPU env vars to check:**
- `__GL_SYNC_TO_VBLANK=0` → vsync off (desirable for VRR)
- `__GL_MaxFramesAllowed=1` → low latency mode (pre-render limit)
- `__GL_VRR_ALLOWED=1` → allows VRR signals to GPU
- `__GL_YIELD=USLEEP` → yield strategy (can reduce stutter)
- `__GL_SHADER_DISK_CACHE_SIZE` → 10 GB is reasonable. If missing, default is 256 MB.
- `DXVK_ASYNC=1` → **obsolete on DXVK 2.x**. Verify version before suggesting removal.
- `DXVK_FRAME_RATE=0` → no DXVK frame cap
- `PROTON_ENABLE_ESYNC=1`, `PROTON_ENABLE_FSYNC=1` → standard gaming optimizations
- `PROTON_ENABLE_NVAPI=1` → NVIDIA-specific features in Proton

**Check for commented-out lines** — users often comment a setting thinking they disabled it, but the same var may be set in another file. Cross-reference ALL env var sources.

### Layer 6: Storage + VM

```bash
echo "=== Mount options ==="
mount | grep "^/dev/" | awk '{print $1, $3, $5, $6}'
echo "=== I/O scheduler ==="
cat /sys/block/nvme*/queue/scheduler
echo "=== Queue depth ==="
cat /sys/block/nvme*/queue/nr_requests
echo "=== Swap ==="
swapon --show
echo "=== ZRAM ==="
zramctl 2>/dev/null || echo "no zram"
echo "=== fstrim ==="
systemctl is-active fstrim.timer
echo "=== I/O pressure stalls ==="
cat /proc/pressure/io
echo "=== VM sysctl ==="
sysctl vm.swappiness vm.vfs_cache_pressure vm.dirty_ratio vm.dirty_background_ratio
```

**Key signals:**
- `noatime` mount option on / and /home — good, reduces metadata writes
- `none` scheduler on NVMe — correct (NVMe with NVMe command set doesn't need I/O scheduling; `none` is optimal)
- **Check free space on / and /home** — ext4 performance degrades past 90% capacity due to reduced contiguous block allocation. `df -h / /home`. If either is >90%, flag it for cleanup.
- **Check for ext4 filesystem errors** — `sudo tune2fs -l /dev/<device> | grep "Filesystem state"`. If it shows "errors" or `sudo fsck.ext4 -fn <device>` returns non-zero, schedule a boot-time fsck with `sudo tune2fs -C 65535 /dev/<device>`.
- `fstrim.timer` active — good for SSD lifetime
- High swap usage with plenty of free RAM — check `swappiness`. Under 10 is standard for desktops with lots of RAM. Some swap (~3 GB on a 64 GB system) is normal — kernel deprioritizes genuinely cold pages.
- `dirty_ratio` and `dirty_background_ratio` — defaults (20/10 or 15/5) are fine for NVMe. For desktops, tighter values (10/3) can reduce write-induced stutter during large I/O. However, too-aggressive writeback (e.g., dirty_background_ratio=3) can increase I/O pressure stalls.
- **I/O pressure stalls** (`/proc/pressure/io`) — check `full avg10` and `full total`. A `full total > 10M` indicates processes are regularly blocked waiting for I/O. On a composited desktop, this compounds input latency because the compositor's frame scheduling pipeline stalls when co-processes (Chrome renderers) block on I/O. Investigate the I/O source if total exceeds 10M between boots. Common causes: aggressive dirty writeback, swap on slow media, or a runaway write-heavy process.
- **Filesystem commit interval** — default ext4 commit interval is 5 seconds. Add `commit=120` to fstab options for more write batching on SSDs. Tradeoff: up to 120s of data loss on power failure. Safe for desktops; use `commit=60` for a middle ground.

### Layer 7: System Services + Failed Services

```bash
echo "=== irqbalance ==="
systemctl is-active irqbalance
echo "=== Failed services ==="
systemctl --failed --no-pager | head -20
echo "=== Timers (what runs during desktop use) ==="
systemctl list-timers --no-pager | head -20
echo "=== Boot/slow services ==="
systemd-analyze
systemd-analyze blame | head -5
echo "=== Loaded unused modules ==="
lsmod | awk '$3==0 {print $1, $2}' | head -20
```

**Key signals:**
- **irqbalance disabled + 4+ CPU cores** = interrupts bottleneck on CPU 0. This is the single highest-impact, lowest-effort finding. Enable it.
- `fstrim.service` showing 6+ minutes in `systemd-analyze blame` is normal for the first-run trim. Not an issue unless it happens on every boot.

## New Layer 11: Context Switch Analysis

```bash
echo "=== TOTAL CONTEXT SWITCHES ==="
cat /proc/stat | grep "^ctxt"
echo "=== UPTIME ==="
cat /proc/uptime | awk '{printf "Uptime: %.0f seconds (%.1f days)\\n", $1, $1/86400}'
echo "=== CURRENT RATE ==="
CTXT1=$(grep "^ctxt" /proc/stat | awk '{print $2}')
sleep 3
CTXT2=$(grep "^ctxt" /proc/stat | awk '{print $2}')
echo "CS/s: $(((CTXT2 - CTXT1) / 3))"
```

### Interpreting Context Switch Rates

| Rate | Assessment |
|---|---|
| <10K/s | Idle desktop, minimal background activity |
| 10-50K/s | Normal desktop with browser + apps |
| 50-100K/s | Under load (compilation, gaming, video) |
| 100K+/s | Elevated — investigate cause |

### Rescheduling IPI Storm Diagnosis

A rescheduling IPI storm is when one CPU core receives 10-20x more RES interrupts than sibling cores of the same type (P or E). This indicates the scheduler is using that CPU as a cross-wakeup hub.

**Quick check:**
```bash
echo "=== RES IPIs by CPU ==="
grep "RES" /proc/interrupts | awk '{for(i=2;i<=20;i++) print (i-2), $i}' | sort -k2 -rn
```

**Thresholds for hybrid CPUs (P-cores 0-7, E-cores 8-19):**
- Healthy P-core (nohz_full): <50K resched IPIs
- Storm P-core: 800K+ resched IPIs
- Healthy E-core: <120K resched IPIs
- Storm E-core: >200K+ (relative to siblings)

**Diagnosing the source:**
The compositor running on a storm core is the primary latency delivery mechanism. Check which task runs on the storm core:

```bash
echo "=== Tasks on storm CPUs ==="
ps -eo pid,tid,psr,comm,user,%cpu --sort=-%cpu | awk '$3==3 || $3==7' | head -10
```

Common storm sources:
- **GPU fault cascade** (NVIDIA Xid 31) → compositor GPU command blocks → scheduler reschedules waiting threads → cross-CPU wakeups increase
- **Chrome renderer thrashing** → each new tab/extension wakes other render processes → resched IPIs accumulate
- **sched_autogroup_enabled=1** → TTY session group switches cause priority cascade (especially on alt-tab)
- **RCU grace period kthread** → `rcu_preempt` on compositor core triggers resched on callback completion

**Fix when storm is from GPU faults:**
Stop the fault source first (e.g., disable Chrome accelerated video decode). The resched storm is a symptom of the compositor blocking on GPU recovery — fixing the GPU fault source resolves the storm.

**Fix when storm is from scheduler/workload:**
```ini
kernel.sched_autogroup_enabled=0   # prevents TTY group priority cascade
kernel.timer_migration=0           # keeps timers local to their CPU
```

Then pin the compositor to E-cores to isolate it from P-core workload churn:
```bash
sudo taskset -pac 0xfff00 $(pgrep kwin_wayland)  # E-cores 8-19 only
```

### Root Cause Breakdown

**Voluntary vs Involuntary CS:**
- **Voluntary** — task yields CPU (waits for I/O, sleeps, syscalls). High voluntary CS is normal for Proton/Wine games (every Windows API call → wineserver IPC → 2+ CS per call). Unity games via DXVK can produce 500K+/session voluntary CS.
- **Involuntary** — kernel forcibly preempts the task (timeslice expired, higher-priority task woke, **hardware IRQ arrived**). High involuntary CS is ALWAYS a problem. It means the task is being yanked off the CPU against its will.

**The most common cause of high involuntary CS on gaming desktops is NOT the scheduler — it's GPU IRQs.** NVIDIA cards with MSI-X enabled can fire 100M+ interrupts per session. If the game thread shares a CPU core with the GPU's primary IRQ, every GPU interrupt preempts the game.

```bash
# Diagnose GPU IRQ preemption:
echo "=== NVIDIA IRQ DISTRIBUTION ==="
grep "nvidia" /proc/interrupts | head -10
echo "=== GAME PID IRQ AFFINITY ==="
GAME_PID=$(pgrep -f "your_game\|wineserver" 2>/dev/null | head -1)
if [ -n "$GAME_PID" ]; then
  cat /proc/$GAME_PID/status | grep "Cpus_allowed_list"
  echo "Currently running on CPU: $(cat /proc/$GAME_PID/stat | awk '{print $39}')"
fi
```

**If a NVIDIA IRQ has 70M+ interrupts on a single CPU, and the game runs on that same CPU, that CPU is being interrupted 70M times — each one a cache flush and potential frame time spike.**

### Fixing High Involuntary CS

**Strategy 1 — Move game away from GPU IRQ cores:**
The fix is NOT to move GPU IRQs (they belong on P-cores for minimal latency). The fix is to pin the game to P-cores that DON'T handle GPU IRQs.

```bash
# Example: if NVIDIA IRQs are on CPUs 0-5, pin game to CPUs 6-7
gamemode config: [cpu] cores=6-7 pin_cores=yes
```

**Strategy 2 — Isolate gaming cores entirely (most effective):**
Use kernel boot params to reserve dedicated P-cores for the game with zero interference:

```
isolcpus=domain,managed_irq,6,7 nohz_full=6,7 rcu_nocbs=6,7
```

This removes CPUs 6-7 from the scheduler pool, stops timer ticks on them, and offloads RCU callbacks. Only tasks explicitly pinned to those cores can use them. Zero involuntary preemption possible.

**Strategy 3 — Spread GPU IRQs across more P-cores:**
If the pin-irqs script assigns NVIDIA IRQs to CPUs 0-5 only, the two heaviest IRQs concentrate on CPU 0 and 2 (easily 70M+ each). Spread across all 8 P-cores (or skip CPU 0 for the heaviest IRQ) to reduce per-core interrupt load.

### Scheduler Settings Impact on CS

Aggressive scheduler sysctl settings directly increase context switch rates:

```
sched_min_granularity_ns=750000    # 0.75ms slices → 1333 preemptions/s/core
sched_wakeup_granularity_ns=1000000 # 1ms → background steals from foreground aggressively
```

At 0.75ms and 60fps (16.7ms/frame): the game gets preempted ~22 times per frame.
At 3ms (default) and 60fps: the game gets preempted ~5 times per frame.

For gaming:
- Keep `sched_min_granularity_ns` at 3ms (default) or higher
- Keep `sched_wakeup_granularity_ns` at 4ms (default) or higher
- `sched_latency_ns` can stay moderate (12ms) for background responsiveness

This is the tradeoff: lower latency for background tasks means more preemption for the foreground game. On a gaming desktop, the foreground game should win.

### Context Switch Budget for Proton/Wine

Proton games have a natural CS budget that cannot be eliminated:
- Each Windows API call → wineserver IPC → **2 mandatory voluntary CS**
- Unity games: 500-2000+ draw calls/frame → 1000-4000 CS/s just for Proton
- DXVK: additional CS for Vulkan command buffer submission
- At 165fps: ~165K-660K CS/s from Proton alone is expected

Do NOT flag Proton CS as a problem unless accompanied by high involuntary CS or measurable performance impact. Voluntary CS from wineserver is the price of Windows emulation.

## New Layer 12: Hybrid CPU / GPU IRQ Management for Gaming

Applies to Intel Core Ultra 200 series (Arrow Lake) and any hybrid CPU with P-cores + E-cores + NVIDIA GPU.

### The Challenge

On hybrid CPUs with an NVIDIA GPU, IRQ distribution must respect two constraints:
1. **GPU IRQs need P-cores** — they're latency-sensitive and frequent (100M+/session). Putting them on E-cores wastes P-core capacity and can cause GPU stalls.
2. **The game also needs P-cores** — but it should avoid the cores handling GPU IRQs, or it gets interrupted by every GPU operation.

### The Pinning Scheme

**Key principle: move ALL IRQs to E-cores on hybrid CPUs.** P-cores should run the game with zero interrupt preemption. E-cores at 4.6 GHz handle IRQs trivially — an IRQ handler runs for microseconds regardless of core type.

```bash
#!/bin/bash
# IRQ pinning: ALL IRQs → E-cores only, no overlap between GPU and USB
# Arrow Lake 265K: P-cores 0-7 (5.4GHz) | E-cores 8-19 (4.6GHz)
#
# E-cores 8-9:   GPU only           ← separate, dedicated
# E-cores 10-11:  USB only           ← separate, dedicated
# E-cores 12-19:  NVMe, audio, WiFi, ethernet
# P-cores 0-7:    untouched — reserved for game/foreground

# 1. NVIDIA GPU → E-cores 8-9 (dedicated, never shared with USB)
i=8
for irq in $(grep "nvidia" /proc/interrupts | awk '{print $1}' | tr -d ':'); do
    core=$((i % 2 + 8))
    echo "$core" > /proc/irq/$irq/smp_affinity_list 2>/dev/null
    ((i++))
done

# 2. USB xHCI → E-cores 10-11 (dedicated, never shared with GPU)
i=10
for irq in $(grep "xhci_hcd" /proc/interrupts | awk '{print $1}' | tr -d ':'); do
    core=$((i % 2 + 10))
    echo "$core" > /proc/irq/$irq/smp_affinity_list 2>/dev/null
    ((i++))
done

# 3. Everything else (NVMe, audio, WiFi, ethernet) → E-cores 12-19
# ...round-robin through i=(12..19)...
```

**Why GPU and USB must be on separate E-cores:**
- GPU generates 100M+ interrupts per gaming session
- USB handles mouse/kb input with strict timing requirements
- If they share the same E-core, GPU IRQ processing can delay USB IRQ handling → input latency spikes
- Each gets its own private pair of E-cores (8-9 for GPU, 10-11 for USB)

**NVMe IRQ caveat:** Some NVMe queue completion IRQs (nvme1q1-nvme1q8) are managed IRQs — the driver may override manual affinity writes. The write appears to succeed (no error) but the kernel reverts it. This is acceptable since NVMe interrupts fire at low rate (hundreds/sec) compared to GPU (100M+/session).

### Game CPU Pinning

The game should run on P-cores that DON'T handle NVIDIA IRQs:
- If NVIDIA IRQs are on CPUs 0-5 → pin game to CPUs 6-7
- If NVIDIA IRQs are on CPUs 1-7 → pin game to CPU 0 (less interrupt load)

Use gamemode for this:
```ini
[cpu]
pin_cores=yes
cores=6-7
```

### The `isolcpus` Approach (Advanced)

For zero-interference gaming cores:
```
isolcpus=domain,managed_irq,6,7 nohz_full=6,7 rcu_nocbs=6,7
```

Then in gamemode:
```ini
[cpu]
pin_cores=yes
cores=6-7
```

The game runs on completely isolated P-cores — no scheduler ticks, no RCU callbacks, no IRQs, no background tasks. Only threads explicitly pinned (via gamemode) can use these cores.

**Caveat:** `isolcpus` removes cores from general scheduler balancing. If the game exits without unpinning, those cores sit idle. This is fine for dedicated gaming desktops. Test with each game to ensure the CPU affinity mask is compatible.

### Detecting the Problem

Signs that GPU IRQs are preempting your game:
1. **High involuntary CS for the game process** — check `/proc/<game_pid>/status` nonvoluntary_ctxt_switches
2. **GPU IRQ concentration** — one CPU has 50M+ more interrupts than others in `grep nvidia /proc/interrupts`
3. **Game thread runs on same CPU as heaviest GPU IRQ** — check `/proc/<game_pid>/stat` field 39 (processor) vs IRQ affinity
4. **CPU pressure elevated on GPU IRQ cores** — `cat /proc/pressure/cpu` shows `some avg10` > 5 on a 20-core system indicates imbalance

```bash
echo "=== PipeWire version ==="
pipewire --version 2>/dev/null | head -3
echo "=== PipeWire quantum/buffer ==="
grep -r "default.clock\|quantum\|node.latency" /etc/pipewire/ 2>/dev/null
grep -r "default.clock\|quantum" ~/.config/pipewire/ 2>/dev/null || echo "no user pipewire config"
echo "=== ALSA cards ==="
cat /proc/asound/cards 2>/dev/null
echo "=== ALSA default config ==="
cat ~/.asoundrc 2>/dev/null || echo "no ~/.asoundrc"
echo "=== Easy Effects ==="
systemctl --user is-active easyeffects 2>/dev/null || pgrep easyeffects >/dev/null && echo "Easy Effects running" || echo "Easy Effects not running"
```

**Key signals:**
- PipeWire default quantum is 1024 at 48 kHz = ~21 ms round-trip latency. For gaming, 256 frames (5.3 ms) is better. Lower quantum reduces audio latency but increases CPU usage. Set via `default.clock.quantum = 256` in pipewire.conf.
- ALSA default card: check whether it routes through NVIDIA HDMI (card 0) or the motherboard codec (card 1, typically PCH). The motherboard codec (ALC1220, ALC897, etc.) has better audio quality and lower latency for system audio. If default is NVIDIA HDMI, suggest switching.
- Easy Effects running adds audio pipeline processing latency. It consumes ~0.5-1% CPU continuously. If the user isn't actively using audio processing/EQ, suggest disabling it.

## New Layer 9: Network Stack

```bash
echo "=== Interface ==="
ip -br link | grep UP | head -5
echo "=== WiFi power save ==="
iw dev 2>/dev/null | grep Interface | awk '{print $2}' | while read iface; do
  echo "$iface: power_save=$(iw dev $iface get power_save 2>/dev/null)"
done
echo "=== TCP congestion control ==="
cat /proc/sys/net/ipv4/tcp_congestion_control
cat /proc/sys/net/ipv4/tcp_available_congestion_control
```

**Key signals:**
- **WiFi power_save=on is one of the highest-impact finds on any laptop/WiFi desktop.** It adds 10-200 ms of network jitter as the NIC wakes from beacon sleep. Disable via `iw dev <iface> set power_save off` and persist via systemd service.
- BBR congestion control should be preferred over cubic for modern networks. Check if BBR is available and active. If cubic is active but BBR is available, recommend switching.
- Check txqueuelen on the active interface. Default 1000 is fine for desktop use.

## New Layer 10: Desktop Environment Effects + Autostart

```bash
echo "=== KWin compositor config ==="
grep -A20 '\\[Compositing\\]' ~/.config/kwinrc 2>/dev/null
echo "=== KWin Plugins section (effects) ==="
grep -A30 '\\[Plugins\\]' ~/.config/kwinrc 2>/dev/null
echo "=== Animation speed ==="
grep AnimationDurationFactor ~/.config/kdeglobals 2>/dev/null
echo "=== Autostart entries ==="
ls ~/.config/autostart/ 2>/dev/null
echo "=== Check autostart entries for duplicates with modprobe ==="
for f in ~/.config/autostart/*.desktop; do
  echo "$f:"
  grep "Exec=" "$f" 2>/dev/null
done
```

**Key signals:**
- `blurEnabled=true` in kwinrc Plugins — blur requires an extra compositing render pass. On NVIDIA Wayland, this adds measurable GPU compositing time. Suggest disabling if the user doesn't actively need it.
- `VrrPolicy=Always` on NVIDIA Wayland can cause constant monitor flickering on desktop because the refresh rate fluctuates with every compositor render change. The fix is `VrrPolicy=FullscreenOnly` — keeps VRR active in fullscreen games but stable on desktop. Apply via: `kwriteconfig5 --file kwinrc --group Compositing --key VrrPolicy FullscreenOnly` then reconfigure KWin or log out/in.
- `AnimationDurationFactor` in kdeglobals — the default is 1.0 (full animation time). Lower values make animations faster, reducing perceived UI lag. Values around 0.5-0.7 are good for a responsive feel without appearing broken.
- Check autostart entries that duplicate modprobe or sysctl settings (e.g., `nvidia-settings -a GPUPowerMizerMode=2` in autostart when modprobe.conf already sets `PowerMizerLevel=0x2`). These are harmless but redundant.
- Check for shell scripts in autostart that set mouse acceleration, IRQ affinity, or other configs. These can conflict with system-level settings.

## Cross-Config Conflict Detection (run AFTER all layers)

After gathering data from all layers, cross-reference for these common conflict patterns:

1. **Boot param duplication** — count occurrences of each param in `/proc/cmdline`. Single params showing 2-3x means grub-mkconfig generated duplicates.
2. **Grub drift** — compare running kernel cmdline (`/proc/cmdline`) against `/etc/default/grub`. A change in grub file that differs from running kernel = unapplied change (needs `sudo update-grub && reboot`).
3. **Module blacklist conflict** — check `/etc/mkinitcpio.conf` `MODULES=` for any module that is also in `/etc/modprobe.d/blacklist*.conf`. The module gets loaded in initramfs, then immediately blocked. This wastes boot time and initramfs size.
4. **IRQ affinity conflict** — check if both `irqbalance.service` AND a custom IRQ pinning service (e.g., `pin-irqs-dynamic.service`) are enabled. They compete — irqbalance dynamically reassigns what the custom script statically pinned.
5. **Env var spreading** — the same env var appearing in 3+ files (`/etc/environment`, `~/.profile`, `~/.config/environment.d/*.conf`). Not harmful but indicates the config evolved organically.
6. **GPU perf mode in two places** — modprobe.conf's `PowerMizerLevel=0x2` + desktop autostart's `nvidia-settings -a GPUPowerMizerMode=2`. The autostart is redundant — modprobe already blocks the GPU from entering lower performance levels.
7. **preempt model mismatch** — grub file says `preempt=full` but `/proc/cmdline` says `preempt=voluntary` = change was made but not rebooted.
8. **Tracing overhead** — check `/proc/sys/kernel/ftrace_enabled`. If 1 on a production desktop, it adds tiny per-function overhead. Set to 0 unless actively debugging.

## Cross-Reference with Research

After gathering all layers, cross-reference findings with current community knowledge. Use the `last30days` skill or web search for:

- `linux performance {specific_finding}` — e.g., "nvidia gsp firmware wayland performance" if GSP is disabled
- `nvidia driver {version} known issues` — check if the installed driver has reported regressions (suspend, WoW performance, etc.)
- `{WAYLAND_COMPOSITOR} {GPU} performance tweaks` — compositor-specific tuning
- `preempt full vs voluntary desktop latency` — if scheduler model is in question

The research provides context about whether each finding is:
- A known issue with community consensus (strong recommendation)
- A debated topic with mixed results (caveated recommendation)
- An edge case that only affects specific hardware/driver combos (mention but deprioritize)

## Recommendation Format

Present findings grouped by impact level. Use this exact format for each recommendation:

### 🔴 High Impact — Fix These First
{n}+ item with clear community consensus and measurable benefit

**Finding:** `[current state]`
**Should be:** `[recommended state]`
**Fix:** `[exact command(s)]`
**Effort:** [time estimate]

### 🟠 Medium Impact — Worth Doing
Items with good evidence but narrower benefit or conditional on workload

### 🟡 Low Impact — Polish
Items that may only matter in edge cases

### ✅ Already Optimal
Quick acknowledgment of what's correctly tuned — shows the user their prior effort wasn't wasted.

## Chrome/Chromium GPU Diagnostics for NVIDIA Wayland

### When to Suspect Software Rendering / Wrong ANGLE Backend

Trigger when user reports:
- "Chrome is slow/choppy on Wayland" (not Firefox — Firefox has native Wayland support and usually works fine)
- "WebGL games/GeoGuessr/Google Maps are unresponsive or low FPS"
- "chrome://gpu shows SwiftShader or Software only on multiple features"
- "GPU context initialization takes long or fails"

### Diagnostic Data to Collect

```bash
# 1. Check which flags Chrome launched with
cat ~/.config/chrome-flags.conf 2>/dev/null    # Arch/Manjaro
cat ~/.config/chromium-flags.conf 2>/dev/null  # Chromium
# Or check running process:
cat /proc/$(pgrep -o chrome 2>/dev/null | head -1)/cmdline 2>/dev/null | tr '\0' ' '

# 2. Check GPU status page (headless mode may not work — try via running instance)
# In browser: chrome://gpu — look for Canvas, WebGL, WebGL2, Rasterization, Vulkan

# 3. Check env vars that affect Chrome GPU path
env | grep -iE "GL|VK_|OZONE|GBM|WAYLAND" | sort

# 4. Check NVIDIA GPU state during Chrome usage
nvidia-smi --query-gpu=utilization.gpu,power.draw,clocks.current.graphics,pstate --format=csv -l 1
```

### How ANGLE Backend Selection Works

Chrome on Linux uses ANGLE (Almost Native Graphics Layer Engine) as its GL→Vulkan/GLES gateway. The flag `--use-gl=angle` enables ANGLE, but ANGLE itself picks a backend via `--use-angle=<backend>`:

| Backend | Best For | Notes |
|---------|----------|-------|
| `vulkan` | Modern NVIDIA (driver 545+) | **Recommended** for NVIDIA Wayland in Chrome 120+ |
| `gl` / `opengl` | NVIDIA with buggy Vulkan support | Stable fallback; no ANGLE GPU reinterpretation overhead |
| `swiftshader` | (default fallback when GPU is blocklisted) | **Software** — catastrophic for WebGL/Canvas |

**Root cause of most Chrome slowness on NVIDIA Wayland:** `--use-gl=angle` without `--use-angle=vulkan`. In this configuration, ANGLE's default backend selection on NVIDIA Wayland can fall back to SwiftShader (software), making Chrome silently render WebGL, Canvas, and GPU rasterization on the CPU — even on a 16GB RTX 5060 Ti.

### Chrome Flags — Diagnosis and Fix

**Known-bad patterns (these cause SwiftShader fallback or driver conflicts):**

| Flags | Problem |
|-------|---------|
| `--use-gl=angle` alone | No backend specified → ANGLE may pick SwiftShader on NVIDIA Wayland |
| `--use-gl=angle --enable-native-gpu-memory-buffers` | `--enable-native-gpu-memory-buffers` conflicts with NVIDIA GBM backend; causes rendering jank or blank frames |
| `--ignore-gpu-blocklist` without `--disable-gpu-driver-bug-workarounds` | GPU is enabled but then hobbled by 50+ driver workarounds |
| `AcceleratedVideoDecodeLinuxGL` (old feature name) | Renamed to `VaapiVideoDecoder` in Chrome 120+ |

**Recommended flags for NVIDIA + Wayland (Chrome 120+):**

```bash
# Option A — ANGLE + Vulkan (most compatible, recommended)
--ozone-platform=wayland
--use-gl=angle
--use-angle=vulkan
--ignore-gpu-blocklist
--disable-gpu-driver-bug-workarounds
--enable-gpu-rasterization
--enable-features=VaapiVideoDecoder,VaapiIgnoreDriverChecks
--num-raster-threads=10

# Option B — Native Desktop GL (simpler, works well on NVIDIA)
--ozone-platform=wayland
--use-gl=desktop
--ignore-gpu-blocklist
--disable-gpu-driver-bug-workarounds
--enable-gpu-rasterization
--enable-features=VaapiVideoDecoder,VaapiIgnoreDriverChecks
--num-raster-threads=10
```

If both options still show SwiftShader in `chrome://gpu`, also add `--disable-features=DefaultANGLEVulkan,Vulkan` to force ANGLE-GL.

### Applying Flags Persistently (Arch-based distros)

Arch/Manjaro's `google-chrome-stable` wrapper script (`/usr/bin/google-chrome-stable`) loads flags from `~/.config/chrome-flags.conf` (one flag per line, no `--` wrapper). Chromium uses `~/.config/chromium-flags.conf`.

The wrapper logic:
```bash
if [[ -f $XDG_CONFIG_HOME/chrome-flags.conf ]]; then
    CHROME_USER_FLAGS="$(grep -v '^#' $XDG_CONFIG_HOME/chrome-flags.conf)"
fi
exec /opt/google/chrome/google-chrome $CHROME_USER_FLAGS "$@"
```

### Verification

After applying flags, restart Chrome and open `chrome://gpu`. Required status:
- **Canvas**: Hardware accelerated  (NOT "Software only")
- **WebGL**: Hardware accelerated  (NOT SwiftShader)
- **WebGL2**: Hardware accelerated
- **Rasterization**: GPU rasterization enabled
- **Video Decode**: Hardware accelerated
- **Vulkan**: Initialized successfully
- **ANGLE Backend**: OpenGL or Vulkan (not SwiftShader)

If any still show software, the flags didn't take effect (check the config file path) or Chrome's internal blocklist is overriding despite `--ignore-gpu-blocklist`.

📎 See `references/chrome-nvidia-wayland-screen-blanking.md` for a full worked case (RTX 5060 Ti, HP X34, KDE 6, Chrome 149).

## KDE PowerDevil + Screen Blanking Diagnostics for NVIDIA Wayland

### The Broken DPMS Monitoring Problem

On KDE Plasma 6 + NVIDIA + Wayland, PowerDevil logs the following during startup:

```
org_kde_powerdevil[1781]: Watching for DPMS state changes unimplemented
```

This means KDE's power management daemon cannot track display power state transitions. When the screen blanks (DPMS off) after the idle timeout, PowerDevil has no reliable signal for when it has actually blanked or when it needs to unblank. This causes screen wake failures where:
- The monitor LED shows signal (ON/active)
- The screen stays black
- Pressing keys or moving the mouse briefly lights up keyboard backlights (USB resumes) but the display stays off

### Diagnostic Data to Collect

```bash
# 1. Full power management config files
cat ~/.config/powerdevilrc          # KDE 6 powerdevil config
cat ~/.config/powermanagementprofilesrc  # Profiles (may also be in powerdevilrc)

# 2. Screen locker config
cat ~/.config/kscreenlockerrc

# 3. KWin compositor config
grep -A5 '\[Compositing\]' ~/.config/kwinrc

# 4. Check for DPMS monitoring broken log
journalctl -b --no-pager | grep -i "dpms.*unimplemented\|powerdevil.*dpms"

# 5. Check actual display/power state
nvidia-smi --query-gpu=pstate,power.draw,temperature.gpu --format=csv
kscreen-doctor -o   # Shows VRR state, HDR, brightness, etc.

# 6. Check whether sleep/suspend services are configured
grep -E "SleepMode|AutoSuspendIdleTimeoutSec|TurnOffDisplayIdleTimeoutSec" \
  ~/.config/powerdevilrc ~/.config/powermanagementprofilesrc 2>/dev/null

# 7. Check NVIDIA suspend/resume services
systemctl status nvidia-suspend nvidia-resume nvidia-hibernate 2>/dev/null

# 8. Check for idle inhibitors being overridden
grep -E "IgnoreIdleInhibitors|BlockedInhibitions" ~/.config/powerdevilrc 2>/dev/null
```

### Root Cause Chain for Screen-Wake Failure

The typical chain (in order of diagnosis):

```
TurnOffDisplayIdleTimeoutSec=300   → Screen blanks after 5 min idle
  + IgnoreIdleInhibitors=true      → Ignores Steam/Chrome "don't sleep" blocks
  + Broken DPMS monitoring         → Can't track blank/unblank transitions
  + AutoSuspendIdleTimeoutSec=3600 → System tries S3 suspend after 1 hour
  + FreeSync/VRR monitor           → Scaler renegotiation adds failure mode
  + NVIDIA suspend/resume sequence → Driver partly enters suspend state
  = Monitor LED on, screen black, KB lights flash on keypress but display won't wake
```

### Fix Options (in priority order)

**Option A — Disable auto-suspend entirely (safest):**
```bash
kwriteconfig6 --file powermanagementprofilesrc --group AC --group SuspendAndShutdown --key AutoSuspendIdleTimeoutSec 0
systemctl --user restart plasma-powerdevil
```

**Option B — Disable display-off timeout (prevents blanking entirely):**
```bash
kwriteconfig6 --file powerdevilrc --group AC --group Display --key TurnOffDisplayIdleTimeoutSec 0
systemctl --user restart plasma-powerdevil
```

**Option C — Remove IgnoreIdleInhibitors (lets apps block sleep properly):**
```bash
kwriteconfig6 --file powerdevilrc --group General --key IgnoreIdleInhibitors false
kwriteconfig6 --file powerdevilrc --group Inhibitions --key BlockedInhibitions ""
systemctl --user restart plasma-powerdevil
```

### Key Config Locations

KDE 6 split power management config across two files:

| File | Section | Key | Effect |
|------|---------|-----|--------|
| `powerdevilrc` | `[AC][Display]` | `TurnOffDisplayIdleTimeoutSec` | Seconds before screen blanks (0=never) |
| `powerdevilrc` | `[AC][Display]` | `DimDisplayIdleTimeoutSec` | Seconds before screen dims (0=never) |
| `powerdevilrc` | `[General]` | `IgnoreIdleInhibitors` | If true, overrides app "don't sleep" requests |
| `powerdevilrc` | `[Inhibitions]` | `BlockedInhibitions` | Comma-separated app:reason pairs to always ignore |
| `powermanagementprofilesrc` | `[AC][SuspendAndShutdown]` | `AutoSuspendIdleTimeoutSec` | Seconds before auto-suspend (0=never) |
| `powermanagementprofilesrc` | `[AC][SuspendAndShutdown]` | `SleepMode` | 0=freeze, 1=suspend-to-idle (S0ix), 2=suspend-to-RAM (S3), 3=suspend-to-disk |
| `powermanagementprofilesrc` | `[Migration]` | `MigratedProfilesToPlasma6` | Indicates the profile was migrated from KDE 5 |
| `kscreenlockerrc` | `[Daemon]` | `Autolock` | If false, screen doesn't lock on blank |
| `kscreenlockerrc` | `[Daemon]` | `LockOnResume` | If false, screen doesn't lock on resume from suspend |

### PolicyAgent D-Bus Inhibition

KDE 6's Policy Agent uses the `/org/kde/Solid/PowerManagement/PolicyAgent` object:

```bash
# Add inhibition (bitmask: 1=logout, 2=suspend, 4=screen off)
qdbus6 org.kde.Solid.PowerManagement \
  /org/kde/Solid/PowerManagement/PolicyAgent \
  org.kde.Solid.PowerManagement.PolicyAgent.AddInhibition 6 \
  "Reason description" "Detailed explanation"

# Release by cookie
qdbus6 org.kde.Solid.PowerManagement \
  /org/kde/Solid/PowerManagement/PolicyAgent \
  org.kde.Solid.PowerManagement.PolicyAgent.ReleaseInhibition <cookie>

# Check if inhibition of type(s) exists
qdbus6 org.kde.Solid.PowerManagement \
  /org/kde/Solid/PowerManagement/PolicyAgent \
  org.kde.Solid.PowerManagement.PolicyAgent.HasInhibition 2  # suspend only
```

Note: `AddInhibition` inhibitions are **not persistent** — they're released when the caller process exits. For permanent changes, use kwriteconfig6 on the config files.

### VRR Monitor Blanking Interaction

FreeSync monitors (like the HP X34) can compound the DPMS wake failure because the monitor's scaler needs to renegotiate the VRR range when waking from blank/suspend. If the NVIDIA driver and the monitor can't agree on the link training parameters during renegotiation, the display stays black. Check:

```bash
kscreen-doctor -o | grep Vrr
```

Recommended VRR policy for NVIDIA Wayland: `VrrPolicy=FullscreenOnly` (prevents desktop-wide VRR fluctuations while keeping VRR in games):

```bash
kwriteconfig6 --file kwinrc --group Compositing --key VrrPolicy FullscreenOnly
qdbus6 org.kde.KWin /Compositor org.kde.kwin.Compositing.reconfigure
```

📎 See `references/chrome-nvidia-wayland-screen-blanking.md` for the full investigation log including specific env vars found, D-Bus PolicyAgent API, and config file structure.

## Common Pitfalls (learned from production audits)

1. **Don't flag SMT=0 on Arrow Lake.** Intel Core Ultra 200 series (Arrow Lake) P-cores have NO Hyper-Threading. SMT being disabled is expected.
2. **Don't propose GSP firmware enable without checking firmware files exist.** `ls /lib/firmware/nvidia/` must show the GPU architecture directory (e.g., gb206 for RTX 5060 Ti). If absent, `NVreg_EnableGpuFirmware=0` is correct.
3. **DXVK_ASYNC was removed in DXVK 2.0.** Don't suggest removing it without first checking `dxvk --version` or the installed DXVK package version. If user is on old DXVK (<2.0), the flag still works.
4. **intel_pstate "powersave" ≠ ACPI "powersave".** On `intel_pstate=active`, "powersave" governor means "dynamically scale from high baseline." The real signal is `energy_performance_preference`. Read both before judging.
5. **Check all env var sources.** A setting may be commented out in one file but active in another. Cross-reference `/etc/environment`, `~/.profile`, `~/.config/environment.d/*.conf`, and shell rc files. The systemd user environment (`environment.d/`) is especially important for Wayland apps launched by KDE.
6. **irqbalance is the highest-ROI fix** on multi-core systems. It costs nearly zero CPU time and distributes interrupt load across all cores. Don't skip checking it just because it seems trivial.
7. **NVIDIA driver version matters for Wayland.** Older drivers (<545) had significant Wayland issues. Driver 595+ (as of mid-2026) is mature for Wayland + VRR. If user is on a much older driver, recommend upgrading before any other tweaks.
8. **Power limit changes reset on reboot.** `nvidia-smi -pl <value>` is ephemeral. Recommend a systemd service or udev rule for persistence if the user wants it permanent.
9. **Module loaded in mkinitcpio but blacklisted** is wasted boot time. Check `MODULES=` in `/etc/mkinitcpio.conf` against `/etc/modprobe.d/blacklist*.conf`. If a module appears in both, remove it from MODULES and rebuild.
10. **Boot param duplication in /proc/cmdline** happens when grub-mkconfig duplicates a param (e.g., `transparent_hugepage=madvise` appearing 3x). The kernel uses the last value, but the excess is noise. Regenerate with `sudo update-grub`.
11. **C-state wake latency matters for gaming/audio/UI.** Check `cat /sys/devices/system/cpu/cpu0/cpuidle/state*/latency`. If any state has latency >200 μs (especially 1048 μs C3 on modern Intel), suggest `intel_idle.max_cstate=2` to block deep C-states. Tradeoff: ~1-3W extra idle power.
12. **ftrace_enabled=1 adds tiny per-function overhead.** On a production desktop it should be 0. Check `cat /proc/sys/kernel/ftrace_enabled` and set `kernel.ftrace_enabled=0` in sysctl.d if 1.
13. **WiFi power_save=on is a major unaddressed latency source** on any laptop or WiFi-desktop. Check with `iw dev <iface> get power_save`. Disable with `iw dev <iface> set power_save off`.
14. **Ext4 filesystem errors happen silently.** Writeback errors may not surface to userspace. Use `sudo tune2fs -l /dev/nvme... | grep "Filesystem state"` or schedule a boot-time fsck with `sudo tune2fs -C 65535 /dev/nvme...` to force a check on next boot.
15. **/home over 90% full degrades ext4 performance.** Available inodes may be fine, but contiguous block allocation becomes harder. Flag it if the partition exceeds 90% usage.
16. **Custom IRQ pinning scripts conflict with irqbalance.** If a user has a custom `pin-irqs-dynamic.service` that manually sets smp_affinity per IRQ (e.g., `echo $core > /proc/irq/$irq/smp_affinity_list`), enabling irqbalance will override those static assignments. Recommend one approach, not both.
17. **LIBVA_DRIVER_NAME variants conflict across env sources.** The VA-API backend was renamed from `nvidia` (legacy) to `nvidia_vulkan` (modern, driver 545+). If `~/.config/environment.d/99-chrome-vaapi.conf` sets `LIBVA_DRIVER_NAME=nvidia` but `~/.profile` sets `LIBVA_DRIVER_NAME=nvidia_vulkan`, apps launched via systemd user session get the legacy backend while shell-launched apps get the modern one. Cross-reference ALL env var sources when checking this var. Prefer `nvidia_vulkan` for driver 545+.
18. **KDE5 env var relics persist on KDE6 and do nothing.** Variables like `KWIN_TRIPLE_BUFFER=0` (KDE5) remain in `~/.profile` but have no effect on KDE Plasma 6. The KDE6 equivalent is `KWIN_DRM_DISABLE_TRIPLE_BUFFERING=1`. Flag these as cleanup items — they're harmless but indicate stale config.
19. **Modprobe.d options for blacklisted modules are dead config.** If a conf file like `/etc/modprobe.d/arrow-lake-ai.conf` contains `options i915 enable_guc=2` but `i915` is blacklisted in `/etc/modprobe.d/blacklist-i915.conf`, the `options` line is parsed but never applied because the module never loads. Cross-reference all `options` lines in modprobe.d against `blacklist` entries.
20. **ALSA default card may route through NVIDIA HDMI instead of motherboard codec.**

21. **Custom IRQ pinning is intentional on hybrid CPUs — don't suggest irqbalance without checking.** Users with P-core/E-core CPUs may have a custom `pin-irqs-dynamic.service` that deliberately places GPU IRQs on P-cores (0-7) and everything else (NVMe, audio, WiFi) on E-cores (8-19). Enabling irqbalance would override this scheme and may put GPU IRQs on E-cores, causing GPU stalls. Before suggesting irqbalance, check both `systemctl is-active irqbalance` AND `systemctl is-active pin-irqs-dynamic` (or similar custom services). If both exist and the user has a hybrid CPU, explain the conflict and let them choose which strategy to use.

22. **Intel IOMMU on RTX 5000 series causes NVDEC0 faults and adds GPU present latency.** `intel_iommu=on` adds DMA translation overhead to every Wayland buffer exchange (0.1-0.5ms per frame) and triggers NVIDIA Xid 31 GPU MMU faults on RTX 5060 Ti (GB206) under Chrome hardware video decode. On a desktop with no VM passthrough (VFIO), IOMMU provides zero benefit. Recommended: remove `intel_iommu=on` from kernel cmdline. Do NOT flag IOMMU as "correct" without checking whether the user actually needs passthrough VMs.

23. **USB autosuspend adds intermittent input latency.** When a USB keyboard's `power/autosuspend` is set to a positive value (default 2 seconds), the USB port suspends after idle. Resume takes 3-10ms on xHCI. Combined with deep C-state exit latency (500-1000µs), an idle-then-type cycle can add 4-11ms of variable latency. Fix: udev rule setting `ATTR{power/autosuspend}="-1"` for the keyboard's vendor:product ID. This is a high-ROI finding when auditing input latency.

24. **GPU + USB IRQs on the same CPU core causes input latency spikes under GPU load.** NVIDIA GPU interrupts can hit 100M+/session. If a USB IRQ shares a core with a GPU IRQ, GPU interrupt processing can delay USB IRQ handling by hundreds of microseconds per interrupt. Separate them via IRQ pinning. On hybrid CPUs, dedicate different E-core pairs: NVIDIA→8-9, USB→10-11.

22. **Game involuntary CS is usually from GPU IRQs, not the scheduler.** When a user reports high involuntary context switches for a game, the natural instinct is to blame scheduler settings (`sched_min_granularity_ns`). But on NVIDIA systems, GPU interrupts (MSI-X) can hit 70M+/session on a single CPU. If the game thread coincidentally runs on that CPU, every GPU interrupt preempts it. Diagnose by checking `grep nvidia /proc/interrupts` for concentration, then checking which CPU the game runs on (`/proc/<pid>/stat` field 39). The fix is to pin the game to P-cores that DON'T host GPU IRQs, not to change scheduler values.

23. **Proton/Wine games have inherently high voluntary CS — don't flag it.** Every Windows API call through Proton goes through wineserver IPC, which adds at minimum 2 voluntary CS per call. Unity games produce 500-2000+ draw calls per frame. At 165fps, that's 165K-660K voluntary CS/s from Proton alone. This expected. Only flag CS as a problem when involuntary CS is high (GPU IRQ preemption) or when there's measurable performance impact.

27. **GPU Xid 31 faults can cause input latency without crashing the system.** Multiple NVIDIA Xid 31 MMU faults from Chrome NVDEC0 degrade the GPU VA space manager, causing every subsequent GPU operation (including compositor frames) to block on driver recovery. This manifests as mouse lag, not a crash. Check `journalctl -k | grep 'Xid.*: 31,'` — if >5 hits, disable Chrome's accelerated video decode and verify the compositor's CPU is not in a resched IPI storm.
28. **Rescheduling IPI storms on compositor CPU cores are a key latency signal, not just a scheduler curiosity.** When `/proc/interrupts` shows one P-core with 800K+ RES IPIs vs siblings with <50K, and the compositor runs on the storm core, that's the latency delivery mechanism. The root cause is often a blocking GPU driver (NVIDIA fault recovery), not the scheduler itself. Fix the GPU fault source first.

25. **`isolcpus` is the nuclear option for gaming latency — explain the tradeoffs.** `isolcpus=domain,managed_irq,6,7 nohz_full=6,7 rcu_nocbs=6,7` removes cores from the scheduler pool and stops timer ticks. It eliminates involuntary CS on those cores but also means: (a) those cores cannot run background tasks, (b) kernel threads are excluded, (c) if the game doesn't properly pin threads to those cores, the isolation is wasted. Recommended only for dedicated gaming desktops where the user controls which games run. Always pair with gamemode CPU pinning (`cores=6-7 pin_cores=yes`).

26. **Scheduler values for gaming need HIGHER granularity, not lower.** Low `sched_min_granularity_ns` (0.75ms) means tasks run for shorter bursts before preemption. On a gaming desktop, this HURTS the foreground game because it gets preempted ~22 times per frame (at 60Hz) instead of ~5. Default or higher values (3ms+) give the game longer uninterrupted windows. The tradeoff is slightly less responsive background tasks — which is acceptable on a gaming desktop. The foreground game should win. The `~/.asoundrc` default PCM device can point to card 0 (NVIDIA HDMI) when card 1 (PCH/motherboard) has better quality. Check `cat /proc/asound/cards` then `grep "card" ~/.asoundrc`. The motherboard codec typically has lower latency and higher quality for system audio.
