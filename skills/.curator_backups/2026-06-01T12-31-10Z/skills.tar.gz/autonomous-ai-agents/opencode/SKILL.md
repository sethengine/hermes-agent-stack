---
name: opencode
description: "Delegate coding to OpenCode CLI (features, PR review)."
version: 1.2.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [Coding-Agent, OpenCode, Autonomous, Refactoring, Code-Review]
    related_skills: [claude-code, codex, hermes-agent]
---

# OpenCode CLI

Use [OpenCode](https://opencode.ai) as an autonomous coding worker orchestrated by Hermes terminal/process tools. OpenCode is a provider-agnostic, open-source AI coding agent with a TUI and CLI.

## When to Use

- User explicitly asks to use OpenCode
- You want an external coding agent to implement/refactor/review code
- You need long-running coding sessions with progress checks
- You want parallel task execution in isolated workdirs/worktrees

## Prerequisites

- OpenCode installed: `npm i -g opencode-ai@latest` or `brew install anomalyco/tap/opencode`
- Auth configured: `opencode auth login` or set provider env vars (OPENROUTER_API_KEY, etc.)
- Verify: `opencode auth list` should show at least one provider
- Git repository for code tasks (recommended)
- `pty=true` for interactive TUI sessions

## Binary Resolution (Important)

Shell environments may resolve different OpenCode binaries. If behavior differs between your terminal and Hermes, check:

```
terminal(command="which -a opencode")
terminal(command="opencode --version")
```

If needed, pin an explicit binary path:

```
terminal(command="$HOME/.opencode/bin/opencode run '...'", workdir="~/project", pty=true)
```

## One-Shot Tasks

Use `opencode run` for bounded, non-interactive tasks:

```
terminal(command="opencode run 'Add retry logic to API calls and update tests'", workdir="~/project")
```

Attach context files with `-f`:

```
terminal(command="opencode run 'Review this config for security issues' -f config.yaml -f .env.example", workdir="~/project")
```

Show model thinking with `--thinking`:

```
terminal(command="opencode run 'Debug why tests fail in CI' --thinking", workdir="~/project")
```

Force a specific model:

```
terminal(command="opencode run 'Refactor auth module' --model openrouter/anthropic/claude-sonnet-4", workdir="~/project")
```

## Interactive Sessions (Background)

For iterative work requiring multiple exchanges, start the TUI in background:

```
terminal(command="opencode", workdir="~/project", background=true, pty=true)
# Returns session_id

# Send a prompt
process(action="submit", session_id="<id>", data="Implement OAuth refresh flow and add tests")

# Monitor progress
process(action="poll", session_id="<id>")
process(action="log", session_id="<id>")

# Send follow-up input
process(action="submit", session_id="<id>", data="Now add error handling for token expiry")

# Exit cleanly — Ctrl+C
process(action="write", session_id="<id>", data="\x03")
# Or just kill the process
process(action="kill", session_id="<id>")
```

**Important:** Do NOT use `/exit` — it is not a valid OpenCode command and will open an agent selector dialog instead. Use Ctrl+C (`\x03`) or `process(action="kill")` to exit.

### TUI Keybindings

| Key | Action |
|-----|--------|
| `Enter` | Submit message (press twice if needed) |
| `Tab` | Switch between agents (build/plan) |
| `Ctrl+P` | Open command palette |
| `Ctrl+X L` | Switch session |
| `Ctrl+X M` | Switch model |
| `Ctrl+X N` | New session |
| `Ctrl+X E` | Open editor |
| `Ctrl+C` | Exit OpenCode |

### Resuming Sessions

After exiting, OpenCode prints a session ID. Resume with:

```
terminal(command="opencode -c", workdir="~/project", background=true, pty=true)  # Continue last session
terminal(command="opencode -s ses_abc123", workdir="~/project", background=true, pty=true)  # Specific session
```

## Common Flags

| Flag | Use |
|------|-----|
| `run 'prompt'` | One-shot execution and exit |
| `--continue` / `-c` | Continue the last OpenCode session |
| `--session <id>` / `-s` | Continue a specific session |
| `--agent <name>` | Choose OpenCode agent (build or plan) |
| `--model provider/model` | Force specific model |
| `--format json` | Machine-readable output/events |
| `--file <path>` / `-f` | Attach file(s) to the message |
| `--thinking` | Show model thinking blocks |
| `--variant <level>` | Reasoning effort (high, max, minimal) |
| `--title <name>` | Name the session |
| `--attach <url>` | Connect to a running opencode server |

## Procedure

1. Verify tool readiness:
   - `terminal(command="opencode --version")`
   - `terminal(command="opencode auth list")`
2. For bounded tasks, use `opencode run '...'` (no pty needed).
3. For iterative tasks, start `opencode` with `background=true, pty=true`.
4. Monitor long tasks with `process(action="poll"|"log")`.
5. If OpenCode asks for input, respond via `process(action="submit", ...)`.
6. Exit with `process(action="write", data="\x03")` or `process(action="kill")`.
7. Summarize file changes, test results, and next steps back to user.

## PR Review Workflow

OpenCode has a built-in PR command:

```
terminal(command="opencode pr 42", workdir="~/project", pty=true)
```

Or review in a temporary clone for isolation:

```
terminal(command="REVIEW=$(mktemp -d) && git clone https://github.com/user/repo.git $REVIEW && cd $REVIEW && opencode run 'Review this PR vs main. Report bugs, security risks, test gaps, and style issues.' -f $(git diff origin/main --name-only | head -20 | tr '\n' ' ')", pty=true)
```

## Parallel Work Pattern

Use separate workdirs/worktrees to avoid collisions:

```
terminal(command="opencode run 'Fix issue #101 and commit'", workdir="/tmp/issue-101", background=true, pty=true)
terminal(command="opencode run 'Add parser regression tests and commit'", workdir="/tmp/issue-102", background=true, pty=true)
process(action="list")
```

## Session & Cost Management

List past sessions:

```
terminal(command="opencode session list")
```

Check token usage and costs:

```
terminal(command="opencode stats")
terminal(command="opencode stats --days 7 --models anthropic/claude-sonnet-4")
```

## System Prompt & Agent Configuration

OpenCode's system prompt for each LLM call is assembled from:
1. **Provider-specific prompt** (built-in: `default.txt`, `anthropic.txt`, `gpt.txt`, etc.)
2. **Environment info** (working dir, platform, model name — auto-injected)
3. **Instruction files** (`AGENTS.md`, `CLAUDE.md`, `CONTEXT.md` — auto-loaded)
4. **Agent prompt override** (from `opencode.json` agent config)

You can customize agent behavior at multiple levels:

### Level 1: Project instructions (AGENTS.md)
Create `AGENTS.md` at project root or `~/.config/opencode/AGENTS.md` for global context. OpenCode auto-loads the first `AGENTS.md` found walking up from cwd. Use for project conventions, coding rules, architecture notes.

### Level 2: Agent config in opencode.json
Override the system prompt for specific agents:

```json
{
  "agent": {
    "power": {
      "prompt": "{file:./prompt.md}",
      "temperature": 0.3,
      "mode": "all",
      "tools": { "searxng": true, "github": true }
    }
  }
}
```

The `{file:./path}` syntax reads a local file's content as the prompt value. Paths resolve relative to the config file's directory. `~/` and absolute paths also work. `{env:VAR_NAME}` for env vars.

### Level 3: Markdown agent files
Create `~/.config/opencode/agents/<name>.md` with YAML frontmatter + prompt body:

```markdown
---
description: Reviews code for quality
model: anthropic/claude-sonnet-4-20250514
temperature: 0.1
mode: subagent
permission:
  edit: deny
---

You are a code reviewer. Focus on bugs, security, and quality.
```

### Prompt Assembly Order
`system = [...env_info, ...instructions, ...(skills if enabled)]`

The agent's `prompt` field replaces the built-in provider prompt for that agent. AGENTS.md / CLAUDE.md instructions are always appended.

### Key Pitfall: Prompt Length
OpenCode compacts context near the window limit. Long system prompts consume tokens that could be used for conversation. Keep AGENTS.md concise — if rules get ignored, the file is probably too long. For deep system prompts, use `{file:./path}` to keep the config clean.

See `references/opencode-prompt-architecture.md` for full details on prompt assembly, agent schema fields, and subagent configuration.

## MCP Server Configuration

MCP servers in `~/.config/opencode/opencode.json` under the `"mcp"` key. See `references/opencode-mcp-servers.md` for full Docker networking patterns, env var pitfalls, and per-image config — here are the essentials:

- **Env vars**: Put secrets in `environment` dict, NOT inline in `command` array. The command should have `-e VARNAME` (no `=`), and the dict provides the value.
- **Docker networking**: MCP containers that need to reach other containers must be on the same Docker network. Use `--network <net>` in the command and `docker network connect --alias <name>` on the target.
- **`host.docker.internal`**: On Linux, add `--add-host=host.docker.internal:host-gateway` to Docker MCP commands that need host access.
- **JSON config keys**: Watch for trailing spaces in provider/MCP keys (e.g., `"lm.studio "` breaks resolution).
- **SearXNG**: Must enable `json` in `search.formats` in `settings.yml` (default is `html` only, returns 403 on API calls).
- **Required env var names**: `BRAVE_API_KEY` (not `brave.api_key`), `GITHUB_PERSONAL_ACCESS_TOKEN`, `SEARXNG_URL`.

Agent tool permissions in `opencode.json` can enable/disable MCP servers per agent via `tools` dict. Keys must match MCP server names exactly.

## Pitfalls

- Interactive `opencode` (TUI) sessions require `pty=true`. The `opencode run` command does NOT need pty.
- `/exit` is NOT a valid command — it opens an agent selector. Use Ctrl+C to exit the TUI.
- PATH mismatch can select the wrong OpenCode binary/model config.
- If OpenCode appears stuck, inspect logs before killing:
  - `process(action="log", session_id="<id>")`
- Avoid sharing one working directory across parallel OpenCode sessions.
- Enter may need to be pressed twice to submit in the TUI (once to finalize text, once to send).

## Verification

Smoke test:

```
terminal(command="opencode run 'Respond with exactly: OPENCODE_SMOKE_OK'")
```

Success criteria:
- Output includes `OPENCODE_SMOKE_OK`
- Command exits without provider/model errors
- For code tasks: expected files changed and tests pass

## Rules

1. Prefer `opencode run` for one-shot automation — it's simpler and doesn't need pty.
2. Use interactive background mode only when iteration is needed.
3. Always scope OpenCode sessions to a single repo/workdir.
4. For long tasks, provide progress updates from `process` logs.
5. Report concrete outcomes (files changed, tests, remaining risks).
6. Exit interactive sessions with Ctrl+C or kill, never `/exit`.
